public class Lid {

    private final int J = 1;  
    private int id;
    private String color;
    private Rectangle rectangle;

    public Lid(int id, String color) {
        this.id = id;
        this.color = color;
        this.rectangle = new Rectangle(0, J, 0, 0, color); 
    }

    public int getId() { return id; }
    public String getColor() { return color; }

    public void draw() { rectangle.draw(); }
    public void makeVisible() { rectangle.makeVisible(); }
    public void makeInvisible() { rectangle.makeInvisible(); }
}
