import java.util.ArrayList;
import java.util.Collections;

/**
 * Clase Tower.
 * 
 * Gestiona las tazas y tapas de la torre, permite su reorganización y consultas.
 * También mantiene el estado de la última operación realizada.
 */
public class Tower {

    private int width;
    private int maxHeight;
    private ArrayList<Cup> cups;
    private boolean lastOperationOk;

    /**
     * Constructor de la torre.
     */
    public Tower(int width, int maxHeight) {
        this.width = width;
        this.maxHeight = maxHeight;
        cups = new ArrayList<>();
        lastOperationOk = false;
    }

    public boolean pushCup(int id) {
        for (Cup cup : cups) if (cup.getId() == id) { lastOperationOk = false; return false; }
        if (cups.size() < maxHeight) { cups.add(new Cup(id)); lastOperationOk = true; return true; }
        lastOperationOk = false; return false;
    }

    public boolean popCup() {
        if (!cups.isEmpty()) { cups.remove(cups.size() - 1); lastOperationOk = true; return true; }
        lastOperationOk = false; return false;
    }

    public boolean removeCup(int id) {
        for (int i = 0; i < cups.size(); i++) {
            if (cups.get(i).getId() == id) { cups.remove(i); lastOperationOk = true; return true; }
        }
        lastOperationOk = false; return false;
    }

    public boolean pushLid(int id) {
        for (Cup cup : cups) {
            if (cup.getId() == id) {
                if (!cup.isCovered()) { cup.cover(); lastOperationOk = true; return true; }
                lastOperationOk = false; return false;
            }
        }
        lastOperationOk = false; return false;
    }

    public boolean popLid() {
        if (!cups.isEmpty()) {
            Cup cup = cups.get(cups.size() - 1);
            if (cup.isCovered()) { cup.uncover(); lastOperationOk = true; return true; }
            lastOperationOk = false; return false;
        }
        lastOperationOk = false; return false;
    }

    public boolean removeLid(int id) {
        for (Cup cup : cups) {
            if (cup.getId() == id && cup.isCovered()) { cup.uncover(); lastOperationOk = true; return true; }
        }
        lastOperationOk = false; return false;
    }

    public void orderTower() { Collections.sort(cups, Collections.reverseOrder()); }
    public void reverseTower() { Collections.reverse(cups); }

    public int height() { return cups.size(); }

    public int[] liddedCups() {
        ArrayList<Integer> ids = new ArrayList<>();
        for (Cup cup : cups) if (cup.isCovered()) ids.add(cup.getId());
        Collections.sort(ids);
        return ids.stream().mapToInt(i -> i).toArray();
    }

    public String[] stackingItems() {
        ArrayList<String> items = new ArrayList<>();
        for (Cup cup : cups) { items.add("cup," + cup.getId()); if (cup.isCovered()) items.add("lid," + cup.getId()); }
        return items.toArray(new String[0]);
    }

    public boolean makeVisible() {
        for (Cup cup : cups) if (!cup.canFitOnScreen()) { lastOperationOk = false; return false; }
        for (Cup cup : cups) cup.makeVisible();
        lastOperationOk = true;
        return true;
    }

    public void makeInvisible() { for (Cup cup : cups) cup.makeInvisible(); lastOperationOk = true; }

    public boolean ok() { return lastOperationOk; }
    public void exit() { System.exit(0); }
}
