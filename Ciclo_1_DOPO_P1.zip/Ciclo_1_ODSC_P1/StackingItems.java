import javax.swing.JOptionPane;

/**
 * Clase StackingItems.
 * 
 * Representa el simulador principal del sistema de apilamiento de tazas.
 * Esta clase coordina las acciones del usuario y delega las operaciones
 * a la clase Tower.
 * 
 * @author Novoa - Sierra
 */
public class StackingItems {

    private Tower tower;
    private boolean visible;

    /**
     * Constructor de la clase.
     * @param width Ancho de la torre.
     * @param maxHeight Altura máxima de la torre.
     */
    public StackingItems(int width, int maxHeight) {
        tower = new Tower(width, maxHeight);
        visible = false;
    }


    public void manageCup(String action, int id) {
        if (action == null) {
            showMessageIfVisible("Acción no válida para tazas.");
            return;
        }
        switch (action.toLowerCase()) {
            case "add": tower.pushCup(id); break;
            case "remove": tower.removeCup(id); break;
            case "pop": tower.popCup(); break;
            default:
                showMessageIfVisible("La acción '" + action + "' no se puede realizar sobre tazas.");
        }
    }


    /**
     * Realiza una acción sobre la tapa de una taza.
     */
    public void manageLid(String action, int id) {
        if (action == null) {
            showMessageIfVisible("Acción no válida para tapas.");
            return;
        }
        switch (action.toLowerCase()) {
            case "add": tower.pushLid(id); break;
            case "remove": tower.removeLid(id); break;
            case "pop": tower.popLid(); break;
            default:
                showMessageIfVisible("La acción '" + action + "' no se puede realizar sobre tapas.");
        }
    }


    /**
     * Reorganiza la torre según el tipo especificado.
    */
    public void reorganizeTower(String type) {
        if (type == null) {
            showMessageIfVisible("Tipo de reorganización no válido.");
            return;
        }
        switch (type.toLowerCase()) {
            case "order": tower.orderTower(); break;
            case "reverse": tower.reverseTower(); break;
            default:
                showMessageIfVisible("El tipo de reorganización '" + type + "' no es válido.");
        }
    }


    /**
     * Consulta información de la torre.
     */
    public Object consultInformation(String type) {
        if (type == null) {
            showMessageIfVisible("Tipo de consulta no válido.");
            return null;
        }
        switch (type.toLowerCase()) {
            case "height": return tower.height();
            case "liddedcups": return tower.liddedCups();
            case "stackingitems": return tower.stackingItems();
            default:
                showMessageIfVisible("La consulta '" + type + "' no es válida.");
                return null;
        }
    }


    /**
     * Hace visible la torre en pantalla.
     */
    public void makeVisible() {
        tower.makeVisible();
        visible = true;
    }

    /**
     * Hace invisible la torre en pantalla.
     */
    public void makeInvisible() {
        tower.makeInvisible();
        visible = false;
    }

    /**
     * Muestra un mensaje si la torre es visible.
     */
    private void showMessageIfVisible(String message) {
        if (visible) {
            JOptionPane.showMessageDialog(null, message);
        }
    }
}
