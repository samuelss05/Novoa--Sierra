public class Cup {

    private int id;
    private int width;
    private int height;
    private boolean covered;
    private String color;
    private Lid lid;
    private Rectangle rectangle;

    public Cup(int id) {
        this(id, 50, 50, "blue"); 
    }

    public Cup(int id, int width, int height, String color) {
        this.id = id;
        this.width = width;
        this.height = height;
        this.color = color;
        this.covered = false;
        this.lid = null;
        this.rectangle = new Rectangle(width, height, 0, 0, color);
    }

    public int getId() { return id; }
    public int getWidth() { return width; }
    public int getHeight() { return height; }
    public boolean isCovered() { return covered; }
    public String getColor() { return color; }

    public void cover() {
        if (!covered) {
            covered = true;
            if (lid == null) {
                lid = new Lid(id, "red");
            }
        }
    }

    public void uncover() {
        if (covered) {
            covered = false;
            lid = null;
        }
    }

    public Lid getLid() { return lid; }

    public void draw() {
        rectangle.draw();
        if (covered && lid != null) lid.draw();
    }

    public void makeVisible() {
        rectangle.makeVisible();
        if (lid != null) lid.makeVisible();
    }

    public void makeInvisible() {
        rectangle.makeInvisible();
        if (lid != null) lid.makeInvisible();
    }

    public boolean canFitOnScreen() {
        return true; 
    }
}
