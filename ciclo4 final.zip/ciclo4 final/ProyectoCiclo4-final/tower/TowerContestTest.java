package tower;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class TowerContestTest {
    private TowerContest contest;

    @Before
    public void setUp() {
        contest = new TowerContest();
    }

    @Test
    public void deberiaRetornarOrdenDescendenteParaAlturaMinima() {
        // n=4, h=7 (2*4 - 1)
        String resultado = contest.solve(4, 7);
        assertEquals("7 5 3 1", resultado);
    }

    @Test
    public void deberiaRetornarOrdenAscendenteParaAlturaMaxima() {
        // n=3, h=9 (3*3)
        String resultado = contest.solve(3, 9);
        assertEquals("1 3 5", resultado);
    }

    @Test
    public void deberiaRetornarImpossibleParaAlturaFueraDeRango() {
        // n=3, min=5, max=9. h=4 es muy bajito, h=10 muy alto.
        assertEquals("impossible", contest.solve(3, 4));
        assertEquals("impossible", contest.solve(3, 10));
    }

    @Test
    public void deberiaRetornarImpossibleParaCasoEspecialN2() {
        // n=4, h=14 (n^2 - 2) -> Caso analizado como imposible
        assertEquals("impossible", contest.solve(4, 14));
    }

    @Test
    public void deberiaResolverCasoMuestra1() {
        // n=4, h=9. El resultado debe ser una de las combinaciones válidas (ej: 7 3 5 1)
        String resultado = contest.solve(4, 9);
        assertNotEquals("impossible", resultado);
        // Validamos que contenga todas las tazas necesarias
        assertTrue(resultado.contains("7") && resultado.contains("5") && 
                   resultado.contains("3") && resultado.contains("1"));
    }
}