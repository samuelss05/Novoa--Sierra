package tower;
public class AcceptanceTest {
    public static void main(String[] args) {
        Tower tower = new Tower(50, 200);
        tower.makeVisible();

        // Prueba 1: Bloqueo por Tapa
        tower.pushCup(3); 
        tower.pushCup(2); 
        tower.pushLid(2); 
        tower.pushCup(1); 

        // Revisamos altura
        int altura = tower.height();
        if (altura > 0) {
            System.out.println("Escenario 1 PASÓ, la altura se calculó");
        } else {
            System.out.println("Escenario 1 FALLÓ, altura = " + altura);
        }

        // Prueba 2: Mirar si la tapa se cuenta como unidad extra 
        String[][] unidades = tower.stackingItems();
        if (unidades.length == 3) {
            System.out.println("Escenario 2 PASÓ, unidades contadas correctamente");
        } else {
            System.out.println("Escenario 2 FALLÓ, unidades detectadas = " + unidades.length);
        }

        // Prueba 3: Mostrar id de tazas con tapa
        int[] conTapa = tower.lidedCups();
        System.out.print("Tazas con tapa: ");
        for (int id : conTapa) {
            System.out.print(id + " ");
        }
        System.out.println("\nFin de la prueba");
    }
}