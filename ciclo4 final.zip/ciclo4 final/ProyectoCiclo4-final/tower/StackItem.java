package tower;

    /**
    * Representa un elemento dentro de la torre.
    * Puede ser una taza o una tapa.
    */
public abstract class StackItem {
    protected int id;
    protected String color;
    protected String type;
    
    /**
     * Crea un elemento de la torre con id, color y tipo.
     */
    public StackItem(int id, String color, String type){
        this.id = id;
        this.color = color;
        this.type = type.toLowerCase();
    }

    /**
     * Retorna el id del elemento.
     */
    public int getId(){
        return id; 
    }
    
    /**
     * Retorna el color del elemento.
     */
    public String getColor(){
        return color;
    }
    
    /**
     * Retorna el tipo del elemento.
     */
    public String getType(){
        return type;
    }
    
    /**
     * Devuelve el ancho del elemento en píxeles.
     */
    public abstract int getPixelWidth();
    
    /**
     * Devuelve la altura del elemento en píxeles.
     */
    public abstract int getPixelHeight();
    
    /**
     * Dibuja el elemento en la posición indicada.
     */
    public abstract void draw(int x, int y);
    
    /**
     * Hace invisible el elemento.
     */
    public abstract void makeInvisible();
    
    /**
     * Hace visible el elemento.
     */
    public abstract void makeVisible();
}