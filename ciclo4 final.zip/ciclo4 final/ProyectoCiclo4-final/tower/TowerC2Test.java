package tower;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

public class TowerC2Test {

    private Tower tower;

    @BeforeEach
    public void setUp() {
        tower = new Tower(600, 500);
        tower.makeInvisible();
    }

    // CONSTRUCTORES 
    @Test
    public void NS_constructorWithWidthHeight() {
        // Esto debería hacer: crear torre vacía
        assertEquals(0, tower.stackingItems().length);

        // Esto no debería hacer: inicializar con elementos
        // assertEquals(1, tower.stackingItems().length); 
    }

    @Test
    public void NS_constructorWithCups() {
        Tower t = new Tower(3); 
        t.makeInvisible();

        // Esto debería hacer: crear 3 tazas
        assertEquals(3, t.stackingItems().length);
        for (int i = 0; i < 3; i++) {
            assertEquals("cup", t.stackingItems()[i][0]);
            assertEquals(String.valueOf(i+1), t.stackingItems()[i][1]);
        }

        // Esto no debería hacer: crear tapas automáticamente
        // assertEquals("lid", t.stackingItems()[0][0]);
    }

    // PRUEBAS PARA PUSH CUP Y POP CUP 
    @Test
    public void NS_pushCup() {
        tower.pushCup(1);
        assertEquals(1, tower.stackingItems().length);
        tower.pushCup(2);
        // Esto debería hacer: aumentar la cantidad de tazas
        assertEquals(2, tower.stackingItems().length);

        // Esto no debería hacer: no agregar la taza
        // assertEquals(1, tower.stackingItems().length); 
    }

    @Test
    public void NS_popCup() {
        tower.pushCup(1);
        tower.pushCup(2);
        tower.popCup();
        // Esto debería hacer: remover la última taza
        assertEquals(1, tower.stackingItems().length);

        // Esto no debería hacer: eliminar la primera taza
        // assertEquals("2", tower.stackingItems()[0][1]); 
    }
    
    // PRUEBA PARA REMOVECUP
    @Test
    public void NS_removeCup() {
        tower.pushCup(1);
        tower.pushCup(2);
        tower.removeCup(1);
        // Esto debería hacer: eliminar la taza con id=1
        assertEquals(1, tower.stackingItems().length);
        assertEquals("2", tower.stackingItems()[0][1]);

        // Esto no debería hacer: eliminar otra taza
        // assertEquals("1", tower.stackingItems()[0][1]); 
    }

    // PRUEBAS PARA PUSH LID Y POP LID 
    @Test
    public void NS_pushLid() {
        tower.pushCup(1);
        tower.pushLid(1);

        // Esto debería hacer: la taza 1 ahora tiene tapa
        int[] lids = tower.lidedCups();
        assertArrayEquals(new int[]{1}, lids);

        // Esto no debería hacer: agregar tapa sin taza
        // assertEquals(2, lids.length); // incorrecto
    }

    @Test
    public void NS_popLid() {
        tower.pushCup(1);
        tower.pushCup(2);
        tower.pushLid(1);
        tower.pushLid(2);
        tower.popLid();
        // Esto debería hacer: remover la última tapa (id=2)
        int[] lids = tower.lidedCups();
        assertArrayEquals(new int[]{1}, lids);

        // Esto no debería hacer: eliminar otra tapa
        // assertArrayEquals(new int[]{2}, lids); 
    }
    
    // PRUEBA PARA REMOVELID
    @Test
    public void NS_removeLid() {
        tower.pushCup(1);
        tower.pushCup(2);
        tower.pushLid(1);
        tower.pushLid(2);
        tower.removeLid(1);
        // Esto debería hacer: eliminar tapa id=1
        int[] lids = tower.lidedCups();
        assertArrayEquals(new int[]{2}, lids);

        // Esto no debería hacer: eliminar otra tapa
        // assertArrayEquals(new int[]{1}, lids); 
    }

    // PRUEBA PARA HEIGHT 
    @Test
    public void NS_height() {
        Tower tower = new Tower(2); 
        tower.pushLid(1);           
        tower.pushLid(3);           
        // Calculo para verificar:
        // Taza 1 = 2*1-1 =1 + tapa = 2
        // Tapa suelta = 1
        // Taza 2 = 2*2-1 =3 (suma porque hay tapa antes) 
        // Total = 2 + 1 + 3 = 6
        int expectedHeight = 6;
        assertEquals(expectedHeight, tower.height());
    }

    // PRUEBA PARA STACKINGITEMS 
    @Test
    public void NS_stackingItems() {
        Tower tower = new Tower(2); 
        tower.pushLid(1);           
        tower.pushLid(3);          
    
        String[][] items = tower.stackingItems();
    
        // Cambia 4 por 3
        assertEquals(3, items.length); 
        assertEquals("cup", items[0][0]); 
        assertEquals("cup", items[1][0]); 
        assertEquals("lid", items[2][0]); 
    }

    // PRUEBA PARA LIDEDCUP ==================
    @Test
    public void NS_lidedCups() {
        tower.pushCup(1);
        tower.pushCup(2);
        tower.pushCup(3);

        tower.pushLid(1);
        tower.pushLid(3);

        // Esto debería hacer: devolver ids de tazas tapadas ordenados
        int[] lids = tower.lidedCups();
        assertArrayEquals(new int[]{1,3}, lids);

        // Esto no debería hacer: incluir tazas sin tapa
        // assertArrayEquals(new int[]{1,2,3}, lids); 
    }

    // PRUEBAS PARA ORDER Y REVERSE TOWER 
    @Test
    public void NS_orderTower() {
        tower.pushCup(3);
        tower.pushCup(1);
        tower.pushCup(2);

        tower.orderTower();
        int[] ids = tower.lidedCups(); 
        // Esto debería hacer: ordenar tazas por id
        String[][] items = tower.stackingItems();
        assertEquals("1", items[0][1]);
        assertEquals("2", items[1][1]);
        assertEquals("3", items[2][1]);

        // Esto no debería hacer: dejar tazas desordenadas
        // assertEquals("3", items[0][1]); 
    }

    @Test
    public void NS_reverseTower() {
        tower.pushCup(1);
        tower.pushCup(2);
        tower.pushCup(3);

        tower.reverseTower();

        // Esto debería hacer: invertir la lista
        String[][] items = tower.stackingItems();
        assertEquals("3", items[0][1]);
        assertEquals("2", items[1][1]);
        assertEquals("1", items[2][1]);

        // Esto no debería hacer: mantener orden original
        // assertEquals("1", items[0][1]);
    }

    // PRUEBAS PARA SWAP Y COVER 
    @Test
    public void NS_swap() {
        tower.pushCup(1);
        tower.pushCup(2);

        tower.swap("cup,1", "cup,2");

        // Esto debería hacer: intercambiar posiciones
        String[][] items = tower.stackingItems();
        assertEquals("2", items[0][1]);
        assertEquals("1", items[1][1]);

        // Esto no debería hacer: dejar elementos sin intercambiar
        // assertEquals("1", items[0][1]); 
    }

    @Test
    public void NS_cover() {
        tower.pushCup(1);
        tower.pushCup(2);
        tower.pushLid(1);

        tower.cover();

        // Esto debería hacer: cubrir todas las tazas
        int[] lids = tower.lidedCups();
        assertArrayEquals(new int[]{1,2}, lids);

        // Esto no debería hacer: dejar alguna taza descubierta
        // assertArrayEquals(new int[]{1}, lids); 
    }

    // PRUEBA PARA SWAPTOREDUCE 
    @Test
    public void NS_swapToReduce() {
        tower.pushCup(1);
        tower.pushCup(3);
        tower.pushCup(2);

        String[][] swap = tower.swapToReduce();

        // Esto debería hacer: devolver un par que reduce altura
        assertNotNull(swap);

        // Esto no debería hacer: devolver par nulo si hay reducción posible
        // assertEquals(0, swap.length); 
    }

}