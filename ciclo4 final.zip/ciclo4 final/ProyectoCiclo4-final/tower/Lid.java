package tower;
import shapes.Rectangle;

public class Lid extends StackItem {
    private Rectangle body;
    private static final int HEIGHT_CM = 1;

    /**
     * Crea una tapa con un id, color y tipo.
     */
    public Lid(int id,String color, String type){
        super(id, color, type);
        body = new Rectangle();
        body.changeSize(5, getPixelWidth());
        body.changeColor(color);
        
    }

    /**
     * Retorna la altura de la tapa en píxeles.
     */
    @Override
    public int getPixelHeight(){ 
        return 5; 
    }
    
    /**
     * Calcula el ancho de la tapa en píxeles según su id.
     */
    @Override
    public int getPixelWidth(){ 
        return 10 * (2*id-1); 
    }
    
    /**
     * Dibuja la tapa en la posición indicada.
     */
    @Override
    public void draw(int x, int y){
        body.changeSize(5, getPixelWidth());
        body.moveTo(x, y);
        makeVisible();
    }

    @Override
    public void makeInvisible(){
        body.makeInvisible();
    }
    
    @Override
    public void makeVisible(){
        body.makeVisible();
    }
    
}