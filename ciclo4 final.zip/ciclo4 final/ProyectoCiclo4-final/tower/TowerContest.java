package tower;
import java.util.*;
import java.util.stream.Collectors;
import javax.swing.JOptionPane;

public class TowerContest {

    private static Map<String, Integer> memoStates = new HashMap<>();

    /**
     * Requisito 14: Resuelve el problema principal.
     */
    public static String solve(int n, int h) {

        if (!isInRange(n, h) || isImpossibleCase(n, h)) {
            return "impossible";
        }

        if (h == minHeight(n)) return generateDescendingOrder(n);
        if (h == maxHeight(n)) return generateAscendingOrder(n);
        if (h == (2*n)+1) return specialCase(n);

        return searchArrangement(n, h);
    }

    // SUPPORT METHODS 

    /**
     * Calcula la altura mínima posible para una torre con n tazas.
     */
    private static int minHeight(int n) {
        return 2 * n - 1;
    }

    /**
     * Calcula la altura máxima posible para una torre con n tazas.
     */
    private static int maxHeight(int n) {
        return n * n;
    }

    /**
     * Verifica si la altura h está dentro del rango válido
     * entre la altura mínima y máxima para n tazas.
     */
    private static boolean isInRange(int n, int h) {
        return h >= minHeight(n) && h <= maxHeight(n);
    }    

    /**
     * Determina si el caso es imposible según las reglas del problema.
     */
    private static boolean isImpossibleCase(int n, int h) {
        boolean impossible = false;
        if (h == (n*n)-2){
            impossible = true;
        }
        return impossible;
    }
    
    /**
     * Organiza las tazas de altura mínima a altura máxima (Orden Ascendente)
     */
    private static String generateAscendingOrder(int n) {
        String res = "";
        for (int i = 0; i < n; i++) {
            res += (2 * (i + 1) - 1) + (i == n - 1 ? "" : " ");
        }
        return res;
    }

    /**
     * Organiza las tazas de altura máxima a altura mínima (Orden Descendente)
     */
    private static String generateDescendingOrder(int n) {
        String res = "";
        for (int i = 0; i < n; i++) {
            res += (2 * (n - i) - 1) + (i == n - 1 ? "" : " ");
        }
        return res;
    }
    
    /**
     * Caso Especial para h = 2n + 1
     */
    private static String specialCase(int n) {
        int[] tower = new int[n];
        boolean[] used = new boolean[n + 1];
        
        int largest = 2 * n - 1;
        tower[0] = largest;
        used[n] = true; 

        tower[1] = 3;
        used[2] = true;

        int idx = 2;
        for (int i = n; i >= 1; i--) {
            if (!used[i]) {
                tower[idx] = 2 * i - 1;
                idx++;
            }
        }

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) {
            sb.append(tower[i]).append(i == n - 1 ? "" : " ");
        }
        return sb.toString();
    }

    /**
     * Intenta encontrar un orden de tazas que produzca exactamente la altura h.
     * Usa intentos aleatorios mezclando las tazas varias veces.
     */
    private static String searchArrangement(int n, int h) {
        List<Integer> cups = new ArrayList<>();
        for (int i = 1; i <= n; i++) cups.add(2 * i - 1);

        Random rnd = new Random();
        for (int attempt = 0; attempt < 5000; attempt++) {
            Collections.shuffle(cups, rnd);
            
            if (calculateHeight(cups) == h) {
                return cups.stream().map(String::valueOf).collect(Collectors.joining(" "));
            }
        }
        return "impossible";
    }

    /**
     * Calcula la altura total de una torre según el orden de las tazas.
     */
    private static int calculateHeight(List<Integer> cups) {
        int maxH = 0;
        int baseFloor = 0;
        int previous = 0;
        for (int i = 0; i < cups.size(); i++) {
            int current = cups.get(i);
            if (i == 0) {
                baseFloor = 0;
            } else {
                baseFloor = (current < previous) ? (baseFloor + 1) : (baseFloor + previous);
            }
            maxH = Math.max(maxH, baseFloor + current);
            previous = current;
        }
        return maxH;
    }
    
    /**
     * Calcula la altura total de una torre según el orden de las tazas.
     * Considera si las tazas se encajan o se apilan.
     */
    private static boolean findFinalRoute(int n, int hTarget, int pos, int maxHeight, int baseFloor, int previousSize, boolean[] used, int[] tower) {
        if (pos == n) {
            return maxHeight == hTarget;
        }

        String state = pos + "|" + maxHeight + "|" + baseFloor + "|" + previousSize;
        if (memoStates.containsKey(state)) return false;

        boolean searchFromLargest = hTarget > (n * n) / 2;

        for (int count = 1; count <= n; count++) {
            int i = searchFromLargest ? (n - count + 1) : count;
            
            if (!used[i]) {
                int size = 2 * i - 1;
                int newBase;

                if (pos == 0) {
                    newBase = 0;
                } else {
                    newBase = (size < previousSize) ? (baseFloor + 1) : (baseFloor + previousSize);
                }

                int top = newBase + size;
                int newMax = Math.max(maxHeight, top);    

                if (newMax <= hTarget) {
                    tower[pos] = size;
                    used[i] = true;
                    if (findFinalRoute(n, hTarget, pos + 1, newMax, newBase, size, used, tower)) return true;
                    used[i] = false;
                }
            }
        }

        memoStates.put(state, 0); 
        return false;
    }
    
     /**
     * Simulación gráfica 
     */
    public static void simulate(int n, int h) {
        String solveResult = solve(n, h);

        if (solveResult.equals("impossible")) {
            JOptionPane.showMessageDialog(null, 
                "No es posible construir una torre de altura " + h + " con " + n + " tazas.", 
                "Error de Simulación", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }
    
        Tower visualizer = new Tower(800, 600); 
        visualizer.makeVisible();
    
        String[] sizes = solveResult.split(" ");
        
        try {
            for (String sizeStr : sizes) {
                int size = Integer.parseInt(sizeStr);
                
                int idForSimulator = (size + 1) / 2;
    
                visualizer.pushCup(idForSimulator);
                
                Thread.sleep(300); 
            }
    
            JOptionPane.showMessageDialog(null, 
                "Simulación completada con éxito.\nOrden: " + solveResult + "\nAltura total: " + h, 
                "Simulación Finalizada", 
                JOptionPane.INFORMATION_MESSAGE);
    
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error durante la simulación: " + e.getMessage());
        }
    }
}