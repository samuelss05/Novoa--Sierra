package tower;
import java.util.*;
import javax.swing.*;
import java.util.Random;


public class Tower {

    private int width;
    private int maxHeight;
    private boolean visible;
    private ArrayList<StackItem> stackItems;       

    /**
     * Constructores
     */
    public Tower(int width, int maxHeight) {
        this.width = width;
        this.maxHeight = maxHeight;
        this.visible = false;
        stackItems = new ArrayList<>();
        
    }

    /**
     * Requisito 10
     * Constructor alternativo: crea n tazas iniciales 
     * con mismo color y tamaños crecientes
     */
    public Tower(int cups ) {
        this(600,500);
        
        for (int i = 1; i <= cups; i++) {
            String color = randomColor();
            Cup c = new Cup(i, color, "normal");
            stackItems.add(c);
        }
        if(visible){
            redraw();
        }
    }

    /**
     * Manage cup- Requisito 2 
     * Agrega una taza de tipo normal a la torre.
     */
    public void pushCup(int id) {
        String color = randomColor();
        Cup cup = new Cup(id, color, "normal");
        stackItems.add(cup);
        
        if(visible){
            redraw();
        }
        
       
    }
    
    /**
     * Agrega una taza a la torre indicando su tipo
     */
    public void pushCup(String type, int id) {

        String color = randomColor();
        Cup cup = new Cup(id, color, type.toLowerCase());
        
        breakFragileCups(cup);
        switch(type.toLowerCase()){
            case "normal":
                stackItems.add(cup);
                break;
            case "opener":
                removeBlockingLidsForCup(cup);
                stackItems.add(cup);
                break;
            case "hierarchical":
                pushHierarchical(cup);
                break;
            case "fragile":
                stackItems.add(cup);
                break;
            default:
                System.out.println("Tipo de taza desconocido: " + type);
                return;
        }
    
        if(visible){
            redraw();
        }
    }

    /**
     * Manage cup- Requisito 2 
     * Elimina la última taza agregada en la torre.
     * No elimina la taza si está bloqueada (por ejemplo, una hierarchical en la base).
     */
    public void popCup() {
        for(int i = stackItems.size()-1; i >= 0; i--){
            StackItem item = stackItems.get(i);
            
            if(item instanceof Cup){
                Cup cup = (Cup) item;
                
                //No eliminar tazas bloqueadas
                if(cup.isLocked()){
                    return;
                }
                
                if (cup.hasLid()){
                    Lid laTapa = cup.getLid();
                    laTapa.makeInvisible();
                    stackItems.remove(laTapa);
                    cup.removeLid();
                }
                
                cup.makeInvisible();
                stackItems.remove(i);
                break;
            }
        }
        if(visible){
            redraw();
        }
    }

    /**
     * Manage cup- Requisito 2 
     * Elimina la taza con el id indicado.
     * Si la taza está bloqueada, no se puede eliminar.
     */
    public void removeCup(int id) {
        for (int i = 0; i < stackItems.size(); i++){
            StackItem item = stackItems.get(i);
            
            if(item instanceof Cup){
                Cup cup = (Cup) item;
                
                if(cup.getId() == id){
                    
                    if(cup.isLocked()){
                        return;
                    }
                    
                    if(cup.hasLid()){
                    cup.getLid().makeInvisible();
                    cup.removeLid();
                    }
                    cup.makeInvisible();
                    stackItems.remove(i);
                    break;
                }
            }
        }
        if(visible){
            redraw();
        }
    }

    /**
     * Manage lid- Requisito 3 
     * Agrega una tapa normal a la taza con el id indicado.
     * Si la taza existe y no tiene tapa, se le coloca.
     * Si no existe la taza, la tapa se agrega como elemento suelto.
     */
    public void pushLid(int id) {
        boolean cupid = false;
        
        for(StackItem item: stackItems){
            
            if(item instanceof Cup){
                Cup cup = (Cup) item;
            
                if(cup.getId() == id){
                    cupid = true;
                    
                    if(!cup.hasLid()){
                        Lid lid = new Lid(id, cup.getColor(), "normal");
                        cup.putLid(lid);
                    }
                    break;
                }
            }
        }
        
        if(!cupid){
            String color = randomColor();
            Lid lidSuelta = new Lid(id,color, "normal");
            stackItems.add(lidSuelta);
            
        }
        redraw();
    }
    
    /**
     * Agrega una tapa con un tipo específico a la torre.
     * La tapa puede comportarse de distintas formas según su tipo,
     */
    public void pushLid(String type, int id) {

        String color = randomColor();
        Lid lid = new Lid(id, color, type.toLowerCase());
    
        switch(type.toLowerCase()){
    
            case "normal":
                placeLidNormally(lid);
                break;
    
            case "fearful":
                if(!existsCup(id)){ 
                    return;
                }
                placeLidNormally(lid);
                break;
    
            case "crazy":
                addToBottom(lid);
                break;
    
            default:
                System.out.println("Tipo inválido");
                return;
        }
    
        if (visible){ 
            redraw();
        }
    }
    
    /**
     * Manage lid- Requisito 3 
     * Elimina la última tapa en la torre.
     * Puede ser una tapa suelta o una tapa sobre una taza.
     * Si la tapa es de tipo fearful, no se elimina.
     */
    public void popLid() {

        for(int i = stackItems.size() - 1; i >= 0; i--){
    
            StackItem item = stackItems.get(i);
    
            //CASO 1: tapa suelta
            if(item instanceof Lid){
                Lid lid = (Lid) item;
    
                if(lid.getType().equals("fearful")){
                    return;
                }
    
                lid.makeInvisible();
                stackItems.remove(i);
                break;
            }
    
            // CASO 2: tapa sobre taza
            if(item instanceof Cup){
                Cup cup = (Cup) item;
    
                if(cup.hasLid()){
                    Lid lid = cup.getLid();
    
                    if(lid.getType().equals("fearful")){
                        return; 
                    }
    
                    lid.makeInvisible();
                    cup.removeLid();
                    break;
                }
            }
        }
    
        if(visible){
            redraw();
        }
    }
    
    /**
     * Manage lid- Requisito 3
     * Elimina la tapa con el id indicado.
     * Puede ser una tapa suelta o una tapa sobre una taza.
     * Si la tapa es de tipo fearful, no se elimina.
     */
    public void removeLid(int id) {

        for(int i = 0; i < stackItems.size(); i++){
    
            StackItem item = stackItems.get(i);
    
            //CASO 1: tapa suelta
            if(item instanceof Lid){
                Lid lid = (Lid) item;
    
                if(lid.getId() == id){
    
                    //fearful NO se elimina
                    if(lid.getType().equals("fearful")){
                        return;
                    }
    
                    lid.makeInvisible();
                    stackItems.remove(i);
                    break;
                }
            }
    
            //CASO 2: tapa sobre taza
            if(item instanceof Cup){
                Cup cup = (Cup) item;
    
                if(cup.hasLid()){
                    Lid lid = cup.getLid();
    
                    if(lid.getId() == id){
    
                        //fearful NO se elimina
                        if(lid.getType().equals("fearful")){
                            return;
                        }
    
                        lid.makeInvisible();
                        cup.removeLid();
                        break;
                    }
                }
            }
        }
    
        if(visible){
            redraw();
        }
    }
    
    
    /**
    * Reorganize tower- requisito 4 y 5
    * Ordena los elementos de la torre de menor a mayor según su id.
    */
    public void orderTower() {
        for(int i = 0; i < stackItems.size()-1; i++){
            for(int j = 0; j < stackItems.size()-1-i; j++){
                if(stackItems.get(j).getId() > stackItems.get(j+1).getId()){
                    StackItem temp = stackItems.get(j);
                    stackItems.set(j, stackItems.get(j+1));
                    stackItems.set(j+1, temp);
                }
            }
        }
        if(visible){
            redraw();
        }
    }
    
    /**
     * Reorganize tower- requisito 4 y 5
     * Invierte el orden actual de los elementos en la torre.
     */
    public void reverseTower() {
        Collections.reverse(stackItems);
        if(visible){
            redraw();
        }
    }
    
    /**
     * Consult information- Requisito 6 y 7
     * Devuelve los ids de las tazas que tienen tapa.
     * Los ids se retornan en orden ascendente.
     */
    public int[] lidedCups(){
        ArrayList<Integer> lidsList = new ArrayList<>();
        for (StackItem item : stackItems) {
            if (item instanceof Cup) {
                Cup cup = (Cup) item;
                if (cup.hasLid()) {
                lidsList.add(cup.getId());
                }
            }
        }
        int[] result = new int[lidsList.size()];
        for (int i = 0; i < lidsList.size(); i++) {
            result[i] = lidsList.get(i);
        }
        
        Arrays.sort(result);
        return result;
    }
    
    /**
     * Consult information- Requisito 6 y 7
     * Calcula la altura total de la torre
     */
    public int height() {
        int totalHeight = 0;
        int ultimateHeight = 0;
        boolean blockedCup = false;
        
        for (StackItem item : stackItems) {
            // Caso 1: El elemento es una TAZA (que puede o no tener tapa)
            if (item instanceof Cup) {
                Cup cup = (Cup) item;
                int hCup = 2 * cup.getId() - 1;
                
                if (ultimateHeight == 0 || blockedCup || hCup > ultimateHeight) {
                    totalHeight += hCup;
                }
                
                if (cup.hasLid()) {
                    totalHeight += 1;
                    blockedCup = true; 
                } else {
                    blockedCup = false;
                }
                
                ultimateHeight = hCup;
            } 
            // Caso 2: El elemento es una TAPA SUELTA
            else if (item instanceof Lid) {
                totalHeight += 1;
                blockedCup = true; 
                ultimateHeight = 0; 
            }
        }
        return totalHeight;
    }
    
    /**
     * Consult information- Requisito 6 y 7
     * Retorna una matriz con los elementos de la torre.
     * Cada posición contiene el tipo y el id de cada elemento.
     */
    public String[][] stackingItems() {
        String [][] info = new String[stackItems.size()][2];
        
        for(int i = 0; i < stackItems.size(); i++){
            StackItem item = stackItems.get(i);
            info[i][0] = item.getType();
            info[i][1] = String.valueOf(item.getId());
        }
        return info;
    }
    
    /**
     * Set visibility- Requisito 8 
     * Hace visible la torre y todos sus elementos.
     */
    public void makeVisible() { 
        visible = true; 
        for(StackItem item: stackItems){
            item.makeVisible();
        }
        redraw(); 
    }
    
    /**
     * Set visibility- Requisito 8 
     * Oculta la torre y todos sus elementos.
     */
    public void makeInvisible() { 
        for(StackItem item: stackItems) item.makeInvisible();
        visible = false;
    }
    
    /**
     * Exit simulator-Requisito 9
     * Vacía la torre y la deja invisible.
     */
    public void exit() { 
        makeInvisible();  
        stackItems.clear();
    }
    
    /**
     * Reorganize Tower-Requisito 11 y 12
     * Intercambia la posición de dos elementos en la torre.
     */
    public void swap(String o1, String o2) {
        StackItem item1 = null; 
        StackItem item2 = null;
        for (StackItem s : stackItems) {
            String repre = s.getType() + "," + s.getId();
            
            if(repre.equals(o1)){
                item1 = s;
            }
            
            if(repre.equals(o2)){
                item2 = s;
            }
        }
        if(item1 == null || item2 == null){
            return;
        }
        
        int pos1 = stackItems.indexOf(item1);
        int pos2 = stackItems.indexOf(item2);
        
        StackItem temp = stackItems.get(pos1);
        stackItems.set(pos1, stackItems.get(pos2));
        stackItems.set(pos2, temp);
        
        if(visible){
            redraw();
        }
    }

    /**
     * Reorganize Tower-Requisito 11 y 12
     * Coloca una tapa a todas las tazas que no tienen.
     */
    public void cover() {
        for(int i = 0; i < stackItems.size(); i++){
            StackItem item = stackItems.get(i);
    
            if(item instanceof Cup){
                Cup cup = (Cup) item;
    
                if(!cup.hasLid()){
                    Lid lid = new Lid(cup.getId(), cup.getColor(), cup.getType());
                    cup.putLid(lid);
                }
            }
        }
    
        if(visible){
            redraw();
        }
    }

    
    /**
     * Consult Information -Requisito 13
     * Busca dos elementos que al intercambiarse reduzcan la altura de la torre
     */
    public String[][] swapToReduce() {
        int alturaOriginal = height();
        for (int i = 0; i < stackItems.size(); i++) {
            for (int j = i + 1; j < stackItems.size(); j++){
                
                StackItem temp = stackItems.get(i);
                stackItems.set(i, stackItems.get(j));
                stackItems.set(j,temp);
                
                int newHeight = height();
                
                if(newHeight < alturaOriginal){
                    String[][] result = new String[2][1];
                    
                    result[0][0] = stackItems.get(j).getType() + "," + stackItems.get(j).getId();
                    result[1][0] = stackItems.get(i).getType() + "," + stackItems.get(i).getId();
                    
                    temp = stackItems.get(i);
                    stackItems.set(i, stackItems.get(j));
                    stackItems.set(j, temp);
                    
                    return result;
                }
                temp = stackItems.get(i);
                stackItems.set(i, stackItems.get(j));
                stackItems.set(j, temp);
            }
        }
        return new String[0][0];
    }

    //Métodos auxiliares para los tipos de tazas y tapas 
    
    /**
     * Coloca una tapa sobre su taza correspondiente si existe.
     * Si no existe la taza, la tapa se agrega como elemento suelto.
     */
    private void placeLidNormally(Lid lid){

        for(StackItem item : stackItems){
            if(item instanceof Cup){
                Cup cup = (Cup) item;

                if(cup.getId() == lid.getId()){
                    if(!cup.hasLid()){
                        cup.putLid(lid);
                    }
                    return;
                }
            }
        }

        stackItems.add(lid);
    }

    /**
     * Elimina las tapas que bloquean la entrada de una taza tipo opener.
     * No elimina tapas de tipo fearful, las cuales detienen el proceso.
     */
    private void removeBlockingLidsForCup(Cup newCup){

        for(int i = stackItems.size()-1; i >= 0; i--){
    
            StackItem item = stackItems.get(i);
    
            // ignorar tapas sueltas
            if(item instanceof Lid){
                continue;
            }
    
            if(item instanceof Cup){
                Cup cup = (Cup) item;
    
                // SOLO si la nueva taza puede entrar ahí
                if(newCup.getId() < cup.getId()){
    
                    if(cup.hasLid()){
                        Lid lid = cup.getLid();
                        
                        //No eliminar si es fearful
                        if(lid.getType().equals("fearful")){
                            break;
                        }
    
                        //Eliminar tapa normal
                        lid.makeInvisible();
                        cup.removeLid();
                    }
    
                } else {
                    break;
                }
            }
        }
    }
    
    
    /**
     * Inserta una taza tipo hierarchical en la torre.
     * Desplaza las tazas más pequeñas que encuentra en su camino.
     * Si logra llegar al fondo, la taza queda bloqueada y no puede eliminarse.
     */
    private void pushHierarchical(Cup newCup){

        ArrayList<StackItem> temp = new ArrayList<>();
    
        while(!stackItems.isEmpty()){
    
            StackItem top = stackItems.get(stackItems.size()-1);
    
            //tapa suelta bloquea
            if(top instanceof Lid){
                break;
            }
    
            Cup c = (Cup) top;
    
            //tapa bloquea completamente
            if(c.hasLid()){
                break;
            }
    
            if(c.getId() < newCup.getId()){
                temp.add(stackItems.remove(stackItems.size()-1));
            } else {
                break;
            }
        }
    
        //si llegó al fondo se bloquea
        if(stackItems.isEmpty()){
            newCup.setLocked(true);
        }
    
        stackItems.add(newCup);
        for(int i = temp.size()-1; i >= 0; i--){
            stackItems.add(temp.get(i));
        }
    }
    
    /**
     * Verifica si existe una taza con ese id en la torre
     */
    private boolean existsCup(int id){
        for(StackItem item : stackItems){
            if(item instanceof Cup){
                if(item.getId() == id){
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     *Inserta un elemento en la base de la torre 
     */
    private void addToBottom(StackItem item){
        stackItems.add(0, item);
    }
    
    /**
     * Elimina las tazas de tipo fragile que sean más pequeñas
     * que la nueva taza que se va a agregar.
     */
    private void breakFragileCups(Cup newCup){

        for(int i = stackItems.size() - 1; i >= 0; i--){
            StackItem item = stackItems.get(i);
    
            if(item instanceof Cup){
    
                Cup cup = (Cup) item;
    
                //SOLO si es fragil y la nueva taza es más grande
                if(cup.getType().equals("fragile") && newCup.getId() > cup.getId()){
    
                    // eliminar tapa si tiene
                    if(cup.hasLid()){
                        cup.getLid().makeInvisible();
                        cup.removeLid();
                    }
    
                    // eliminar taza
                    cup.makeInvisible();
                    stackItems.remove(i);
                }
            }
        }
    }
    
    
    //  Métodos privados 
    private static final String[] COLORS = {
        "red", "yellow", "blue", "magenta", "black", "green"
    };
    
    private String randomColor() {
        Random rand = new Random();
        return COLORS[rand.nextInt(COLORS.length)];
    }
    
    private void redraw() {
        if (!visible) return;
    
        int centroCanvas = 400; 
        int baseInicialY = 500; 
        int[] sueloDeTaza = new int[200005]; 
        Arrays.fill(sueloDeTaza, baseInicialY);
    
        StackItem itemAnterior = null;
    
        for (StackItem item : stackItems) {
            int w = item.getPixelWidth();
            int h = item.getPixelHeight();
            int x = centroCanvas - (w / 2);
            int yPos;
    
            if (itemAnterior == null) {
                yPos = baseInicialY - h;
            } else {
                boolean debeEntrar = (item.getId() < itemAnterior.getId());
                boolean anteriorBloqueado = (itemAnterior instanceof Cup && ((Cup)itemAnterior).hasLid());
    
                if (debeEntrar && !anteriorBloqueado) {
                    yPos = (sueloDeTaza[itemAnterior.getId()] - 5) - h; 
                } else {
                    yPos = (sueloDeTaza[itemAnterior.getId()] - itemAnterior.getPixelHeight()) - h;
                }
            }
    
            item.draw(x, yPos);
            sueloDeTaza[item.getId()] = yPos + h;
            itemAnterior = item;
         }
    }
    
}