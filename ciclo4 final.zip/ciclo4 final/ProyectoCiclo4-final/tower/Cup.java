package tower;
import shapes.Rectangle;

public class Cup extends StackItem {
    private Lid lid;
    private Rectangle left; 
    private Rectangle right; 
    private Rectangle base;
    private boolean locked;
    private static final int GROSOR = 5;

    /**
     * Crea una taza con un id, color y tipo.
     */
    public Cup(int id, String color, String type){
        super(id, color, type);
        this.locked = false;
        left = new Rectangle();
        right = new Rectangle();
        base = new Rectangle();

        left.changeColor(color);
        right.changeColor(color);
        base.changeColor(color);

        left.changeSize(getPixelHeight(), GROSOR);
        right.changeSize(getPixelHeight(), GROSOR);
        base.changeSize(GROSOR, getPixelWidth());
    }

    /**
     * Indica si la taza tiene una tapa.
     */
    public boolean hasLid(){ 
        return lid != null; 
    }
    
    /**
     * Retorna la tapa asociada a la taza.
     */
    public Lid getLid(){ 
        return lid; 
    }
    
    /**
     * Coloca una tapa sobre la taza si no tiene una.
     */
    public void putLid(Lid l){ 
        if(lid == null){
            l.color = this.color;
            lid = l;
        }
    }
    
    /**
     * Elimina la tapa de la taza.
     */
    public void removeLid(){ 
        lid = null; 
    }
    
    /**
     * Define si la taza está bloqueada.
     */
    public void setLocked(boolean locked){
        this.locked = locked;
    }
    
    /**
     * Indica si la taza está bloqueada.
     */
    public boolean isLocked(){
        return locked;
    }

    /**
     * Retorna el tipo de la taza.
     */
    @Override
    public String getType(){ 
        return type; 
    }

    /**
     * Calcula la altura de la taza en píxeles según su id.
     */
    public int getPixelHeight(){ 
        return (2 * id -1) * 10; 
    }
    
    /**
     * Calcula el ancho de la taza en píxeles según su id.
     */
    public int getPixelWidth(){ 
        return (2 * id -1) * 10; 
    }

    @Override
    public void draw(int x, int y) {
        int w = getPixelWidth();
        int h = getPixelHeight();
        
        base.changeSize(GROSOR, w); 
        base.moveTo(x, y + h - GROSOR); 
    
        left.changeSize(h - GROSOR, GROSOR);
        left.moveTo(x, y);
    
        right.changeSize(h - GROSOR, GROSOR);
        right.moveTo(x + w - GROSOR, y);
    
        makeVisible();
        if(hasLid()) {
            lid.draw(x, y - lid.getPixelHeight());
        }
    }
    
    @Override 
    public void makeInvisible(){
       left.makeInvisible();
        right.makeInvisible();
        base.makeInvisible();
        if(hasLid()) lid.makeInvisible();
    }

    @Override
    public void makeVisible(){
        left.makeVisible();
        right.makeVisible();
        base.makeVisible();
        if(hasLid()) lid.makeVisible();
    }
}