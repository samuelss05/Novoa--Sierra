package tower;
public class TowerContestCTest {

    public static void main(String[] args) {
        System.out.println("INICIANDO PRUEBAS CON LIMPIEZA DE TABLERO");

        // --- PRUEBA 1 ---
        System.out.println("Ejecutando Prueba 1...");
        TowerContest tc1 = new TowerContest(); 
        tc1.simulate(4, 9);

        // --- PRUEBA 2 ---
        System.out.println("Ejecutando Prueba 2...");
        TowerContest tc2 = new TowerContest(); 
        tc2.simulate(4, 7);

        // --- PRUEBA 3 ---
        System.out.println("Ejecutando Prueba 3...");
        TowerContest tc3 = new TowerContest(); 
        tc3.simulate(3, 9);

        System.out.println("\n PRUEBAS FINALIZADAS");
    }
}