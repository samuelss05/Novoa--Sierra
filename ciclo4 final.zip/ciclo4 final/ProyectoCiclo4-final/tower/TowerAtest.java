package tower;
import javax.swing.JOptionPane;

public class TowerAtest {

    public static void main(String[] args) {

        testOpenerAndFearful();
        testHierarchicalAndCrazy();
    }

    /**
     * PRUEBA 1:
     * Se verifica que:
     * - opener elimina tapas que bloquean
     * - fearful no puede ser removida
     */
    public static void testOpenerAndFearful() {

        Tower t = new Tower(600, 500);
        t.makeVisible();
    
        try {
            // Paso 1: crear taza grande con tapa (obstáculo)
            t.pushCup("normal", 5);
            Thread.sleep(1000);
    
            t.pushLid("normal", 5);
            Thread.sleep(1000);
    
            // Paso 2: insertar taza opener
            // Debe eliminar la tapa de la 5 y entrar
            t.pushCup("opener", 2);
            Thread.sleep(1500);
    
            // Paso 3: agregar tapa fearful a la taza 2
            // Esta NO debería poder eliminarse
            t.pushLid("fearful", 2);
            Thread.sleep(1500);
    
            // Paso 4: intentar eliminar tapa
            // No debería eliminarse porque es fearful
            t.popLid();
            Thread.sleep(1500);
    
        } catch (InterruptedException e) {
            System.out.println("Error: interrupción durante la animación");
        }
    
        int result = JOptionPane.showConfirmDialog(
            null,
            "¿Observaste que:\n\n"
            + "- La taza opener eliminó la tapa de la taza 5?\n"
            + "- La tapa fearful en la taza 2 NO pudo eliminarse?\n\n"
            + "¿Aceptas el comportamiento mostrado?",
            "Prueba de aceptación 1",
            JOptionPane.YES_NO_OPTION
        );
    
        if(result == JOptionPane.YES_OPTION){
            System.out.println("Prueba 1 aceptada");
        } else {
            System.out.println("Prueba 1 rechazada");
        }
    
        t.exit();
    }

     /**
     * PRUEBA 2:
     * Se verifica que:
     * - hierarchical se posiciona en la base desplazando elementos
     * - crazy se ubica directamente en la base
     */
    public static void testHierarchicalAndCrazy() {

        Tower t = new Tower(600, 500);
        t.makeVisible();

        try {
            // Paso 1: crear varias tazas pequeñas
            // Estas serán desplazadas por la hierarchical
            t.pushCup("normal", 2);
            Thread.sleep(1000);

            t.pushCup("normal", 3);
            Thread.sleep(1000);

            t.pushCup("normal", 4);
            Thread.sleep(1000);

            // Paso 2: insertar taza hierarchical grande
            // Debe bajar hasta la base desplazando las más pequeñas
            t.pushCup("hierarchical", 6);
            Thread.sleep(1500);

            // Paso 3: insertar tapa tipo crazy
            // Esta debe ubicarse directamente en la base de la torre
            t.pushLid("crazy", 8);
            Thread.sleep(1500);

        } catch (InterruptedException e) {
            System.out.println("Error: interrupción durante la animación");
        }

        int result = JOptionPane.showConfirmDialog(
            null,
            "¿Observaste que:\n\n"
            + "- La taza hierarchical descendió hasta la base?\n"
            + "- La tapa crazy se ubicó en la base de la torre?\n\n"
            + "¿Aceptas el comportamiento mostrado?",
            "Prueba de aceptación 2",
            JOptionPane.YES_NO_OPTION
        );

        if(result == JOptionPane.YES_OPTION){
            System.out.println("Prueba 2 aceptada");
        } else {
            System.out.println("Prueba 2 rechazada");
        }

        t.exit();
    }
}