package tower;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Pruebas comunes (CC4) para la clase Tower.
 * Validan el comportamiento general del sistema
 * sin depender de tipos específicos.
 */
public class TowerCC4test {

    private Tower tower;

    @BeforeEach
    public void setUp() {
        tower = new Tower(600, 500);
        tower.makeInvisible();
    }

    // CREACIÓN

    @Test
    public void NS_createEmptyTower() {
        // Esto debería hacer: iniciar vacía
        assertEquals(0, tower.stackingItems().length);

        // Esto no debería hacer: iniciar con elementos
        // assertEquals(1, tower.stackingItems().length);
    }

    // AGREGAR ELEMENTOS
    
    @Test
    public void NS_addCupAndLid() {
        tower.pushCup("normal", 1);
        tower.pushLid("normal", 1);

        // Esto debería hacer: la taza queda cubierta
        assertEquals(1, tower.lidedCups().length);

        // Esto no debería hacer: no registrar la tapa
        // assertEquals(0, tower.lidedCups().length);
    }

    @Test
    public void NS_addLidWithoutCup() {
        tower.pushLid("normal", 5);

        // Esto debería hacer: agregar tapa suelta
        assertEquals(1, tower.stackingItems().length);

        // Esto no debería hacer: ignorar la tapa
        // assertEquals(0, tower.stackingItems().length);
    }

    
    // ELIMINAR ELEMENTOS

    @Test
    public void NS_removeCup() {
        tower.pushCup("normal", 1);
        tower.pushCup("normal", 2);

        tower.removeCup(1);

        // Esto debería hacer: eliminar la taza correcta
        assertEquals(1, tower.stackingItems().length);
        assertEquals("2", tower.stackingItems()[0][1]);

        // Esto no debería hacer: eliminar otra taza
        // assertEquals("1", tower.stackingItems()[0][1]);
    }

    @Test
    public void NS_removeLid() {
        tower.pushCup("normal", 1);
        tower.pushLid("normal", 1);

        tower.removeLid(1);

        // Esto debería hacer: eliminar la tapa
        assertEquals(0, tower.lidedCups().length);

        // Esto no debería hacer: mantener la tapa
        // assertEquals(1, tower.lidedCups().length);
    }

    @Test
    public void NS_popCup() {
        tower.pushCup("normal", 1);
        tower.pushCup("normal", 2);

        tower.popCup();

        // Esto debería hacer: eliminar la última taza
        assertEquals(1, tower.stackingItems().length);

        // Esto no debería hacer: eliminar otra taza
        // assertEquals("2", tower.stackingItems()[0][1]);
    }

    
    // CONSULTAS

    @Test
    public void NS_heightBasic() {
        tower.pushCup("normal", 2); // altura esperada: 3

        // Esto debería hacer: calcular altura correctamente
        assertEquals(3, tower.height());

        // Esto no debería hacer: valor incorrecto
        // assertEquals(2, tower.height());
    }

    @Test
    public void NS_lidedCups() {
        tower.pushCup("normal", 1);
        tower.pushCup("normal", 2);
        tower.pushLid("normal", 1);

        // Esto debería hacer: devolver ids de tazas con tapa
        assertArrayEquals(new int[]{1}, tower.lidedCups());

        // Esto no debería hacer: incluir tazas sin tapa
        // assertArrayEquals(new int[]{1,2}, tower.lidedCups());
    }

    @Test
    public void NS_stackingItems() {
        tower.pushCup("normal", 1);

        String[][] items = tower.stackingItems();

        // Esto debería hacer: reflejar los elementos en la torre
        assertEquals(1, items.length);
        assertEquals("1", items[0][1]);

        // Esto no debería hacer: devolver estructura incorrecta
        // assertEquals(0, items.length);
    }

    // REORGANIZACIÓN

    @Test
    public void NS_orderTower() {
        tower.pushCup("normal", 3);
        tower.pushCup("normal", 1);

        tower.orderTower();

        // Esto debería hacer: ordenar por id
        assertEquals("1", tower.stackingItems()[0][1]);

        // Esto no debería hacer: dejar desordenado
        // assertEquals("3", tower.stackingItems()[0][1]);
    }

    @Test
    public void NS_reverseTower() {
        tower.pushCup("normal", 1);
        tower.pushCup("normal", 2);

        tower.reverseTower();

        // Esto debería hacer: invertir orden
        assertEquals("2", tower.stackingItems()[0][1]);

        // Esto no debería hacer: mantener orden
        // assertEquals("1", tower.stackingItems()[0][1]);
    }

    @Test
    public void NS_swap() {
        tower.pushCup("normal", 1);
        tower.pushCup("normal", 2);

        tower.swap("normal,1", "normal,2");

        // Esto debería hacer: intercambiar posiciones
        assertEquals("2", tower.stackingItems()[0][1]);

        // Esto no debería hacer: dejar igual
        // assertEquals("1", tower.stackingItems()[0][1]);
    }

    
    // OPERACIONES GENERALES

    @Test
    public void NS_cover() {
        tower.pushCup("normal", 1);

        tower.cover();

        // Esto debería hacer: cubrir la taza
        assertEquals(1, tower.lidedCups().length);

        // Esto no debería hacer: dejarla descubierta
        // assertEquals(0, tower.lidedCups().length);
    }

    @Test
    public void NS_exit() {
        tower.pushCup("normal", 1);

        tower.exit();

        // Esto debería hacer: limpiar la torre
        assertEquals(0, tower.stackingItems().length);

        // Esto no debería hacer: dejar elementos
        // assertEquals(1, tower.stackingItems().length);
    }
}