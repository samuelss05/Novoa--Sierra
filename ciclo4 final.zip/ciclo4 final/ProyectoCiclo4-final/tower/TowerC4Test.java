package tower;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

public class TowerC4Test {

    private Tower tower;

    @BeforeEach
    public void setUp() {
        tower = new Tower(600, 500);
        tower.makeInvisible();
    }

    // PRUEBAS PARA PUSH CUP 

    @Test
    public void NS_pushCupNormal() {
        tower.pushCup("normal", 3);

        // Esto debería hacer: agregar una taza normal
        assertEquals(1, tower.stackingItems().length);
        assertEquals("normal", tower.stackingItems()[0][0]);

        // Esto no debería hacer: no agregar la taza
        // assertEquals(0, tower.stackingItems().length);
    }

    @Test
    public void NS_pushCupOpener() {
        tower.pushCup("normal", 5);
        tower.pushLid("normal", 5);

        tower.pushCup("opener", 3);

        // Esto debería hacer: eliminar la tapa que bloquea
        int[] lids = tower.lidedCups();
        assertEquals(0, lids.length);

        // Esto no debería hacer: mantener la tapa
        // assertEquals(1, lids.length);
    }

    @Test
    public void NS_pushCupHierarchical() {
        tower.pushCup("normal", 2);
        tower.pushCup("normal", 3);

        tower.pushCup("hierarchical", 5);

        // Esto debería hacer: bajar y quedar en la base
        String[][] items = tower.stackingItems();
        assertEquals("5", items[0][1]);

        // Esto no debería hacer: quedarse arriba
        // assertEquals("5", items[items.length-1][1]);
    }

    @Test
    public void NS_pushCupFragile() {
        tower.pushCup("fragile", 2);
        tower.pushCup("normal", 5);

        // Esto debería hacer: romper la taza fragile menor
        String[][] items = tower.stackingItems();
        assertEquals(1, items.length);
        assertEquals("5", items[0][1]);

        // Esto no debería hacer: mantener la taza fragile
        // assertEquals(2, items.length);
    }

    
    // PRUEBAS PARA PUSH LID 

    @Test
    public void NS_pushLidNormal() {
        tower.pushCup("normal", 3);
        tower.pushLid("normal", 3);

        // Esto debería hacer: colocar la tapa sobre la taza
        int[] lids = tower.lidedCups();
        assertArrayEquals(new int[]{3}, lids);

        // Esto no debería hacer: no colocar la tapa
        // assertEquals(0, lids.length);
    }

    @Test
    public void NS_pushLidFearful_NoCup() {
        tower.pushLid("fearful", 3);

        // Esto debería hacer: NO agregar la tapa si no existe la taza
        assertEquals(0, tower.stackingItems().length);

        // Esto no debería hacer: agregar la tapa sin taza
        // assertEquals(1, tower.stackingItems().length);
    }

    @Test
    public void NS_pushLidFearful_WithCup() {
        tower.pushCup("normal", 3);
        tower.pushLid("fearful", 3);

        // Esto debería hacer: agregar la tapa porque la taza existe
        int[] lids = tower.lidedCups();
        assertEquals(1, lids.length);

        // Esto no debería hacer: bloquear la inserción
        // assertEquals(0, lids.length);
    }

    @Test
    public void NS_pushLidCrazy() {
        tower.pushCup("normal", 3);
        tower.pushLid("crazy", 1);

        // Esto debería hacer: colocar la tapa en la base
        String[][] items = tower.stackingItems();
        assertEquals("crazy", items[0][0]);

        // Esto no debería hacer: colocarla encima
        // assertEquals("crazy", items[items.length-1][0]);
    }


    @Test
    public void NS_combinedBehavior() {
        tower.pushCup("fragile", 2);
        tower.pushCup("normal", 5); // rompe la fragile

        tower.pushCup("normal", 3);
        tower.pushLid("fearful", 3);

        tower.popLid(); // no debe salir

        // Esto debería hacer:
        // - eliminar fragile
        // - mantener fearful
        String[][] items = tower.stackingItems();
        int[] lids = tower.lidedCups();

        assertEquals(2, items.length);
        assertEquals(1, lids.length);

        // Esto no debería hacer:
        // - mantener fragile
        // - eliminar fearful
        // assertEquals(3, items.length);
        // assertEquals(0, lids.length);
    }
}