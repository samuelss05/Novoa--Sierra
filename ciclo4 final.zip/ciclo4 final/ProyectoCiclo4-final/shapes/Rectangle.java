package shapes;
import java.awt.*;
public class Rectangle {
    private int height;
    private int width;
    private int x;
    private int y;
    private String color;
    private boolean isVisible;

    public Rectangle() {
        height = 30;
        width = 40;
        x = 0;
        y = 0;
        color = "magenta";
        isVisible = false;
    }

    public void makeVisible() {
        isVisible = true;
        draw();
    }

    public void makeInvisible() {
        isVisible = false;
        Canvas.getCanvas().erase(this);
    }

    public void moveTo(int newX, int newY) {
        x = newX;
        y = newY;
        if(isVisible) draw();
    }

    public void changeSize(int newHeight, int newWidth) {
        height = newHeight;
        width = newWidth;
        if(isVisible) draw();
    }

    public void changeColor(String newColor) {
        color = newColor;
        if(isVisible) draw();
    }

    private void draw() {
        if(isVisible) {
            Canvas.getCanvas().draw(this, color, new java.awt.Rectangle(x, y, width, height));
        }
    }
}
