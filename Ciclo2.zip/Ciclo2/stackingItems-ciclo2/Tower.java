import java.util.*;
import javax.swing.*;

/**
 * Tower - versión mejorada estilo estudiante
 * Maneja tazas y tapas, incluyendo tapas sueltas y tapas sobre taza.
 */
public class Tower {

    private int width;
    private int maxHeight;
    private boolean visible;

    private ArrayList<StackItem> stackItems; 
    private ArrayList<Cup> cups;             
    private ArrayList<Lid> looseLids;       

    /**
     * Constructores
     */
    public Tower(int width, int maxHeight) {
        this.width = width;
        this.maxHeight = maxHeight;
        this.visible = false;
        cups = new ArrayList<>();
        looseLids = new ArrayList<>();
        stackItems = new ArrayList<>();
    }

    /**
     * Requisito 10
     * Constructor alternativo: crea n tazas iniciales con mismo color y tamaños crecientes
     */
    public Tower(int numCups, int width, int maxHeight, String color) {
        this(width, maxHeight);
        int sizeCm = 1;
        for (int i = 1; i <= numCups; i++) {
            Cup c = new Cup(i, sizeCm, sizeCm, color);
            cups.add(c);
            stackItems.add(c);
            sizeCm += 2;
        }
    }

    /**
     * Manage cup- Requisito 2 
     */
    public void pushCup(int id, int widthCm, int heightCm, String color) {
        Cup c = new Cup(id, widthCm, heightCm, color);
        cups.add(c);
        stackItems.add(c);
        redraw();
    }

    /**
     * Manage cup- Requisito 2 
     */
    public void popCup() {
        if (!cups.isEmpty()) {
            Cup c = cups.remove(cups.size() - 1);
            if (c.hasLid()) {
                Lid l = c.getLid();
                l.makeInvisible();
                stackItems.remove(l);
                c.removeLid();
            }
            c.makeInvisible();
            stackItems.remove(c);
            redraw();
        }
    }

    /**
     * Manage cup- Requisito 2 
     */
    public void removeCup(int id) {
        Cup c = findCup(id);
        if (c != null) {
            if (c.hasLid()) {
                Lid l = c.getLid();
                l.makeInvisible();
                stackItems.remove(l);
            }
            c.makeInvisible();
            cups.remove(c);
            stackItems.remove(c);
            redraw();
        }
    }

    /**
     * Manage lid- Requisito 3 
     */
    public void pushLid(Integer cupId, String color, int widthCm) {
        if (cupId == null) { 
            int newId = generateUniqueLidId();
            Lid lid = new Lid(newId, widthCm, color);
            looseLids.add(lid);
            stackItems.add(lid);
        } else { 
            Cup c = findCup(cupId);
            if (c != null && !c.hasLid()) {
                Lid lid = new Lid(cupId, c.getWidthCm(), c.getColor());
                c.putLid(lid);
                int pos = stackItems.indexOf(c);
                stackItems.add(pos + 1, lid);
            }
        }
        redraw();
    }
    
    /**
     * Manage lid- Requisito 3 
     */
        public void popLid() {
        
        for (int i = stackItems.size() - 1; i >= 0; i--) {
            StackItem item = stackItems.get(i);
            if (item instanceof Lid) {
                Lid l = (Lid) item;
    
               
                if (looseLids.contains(l)) {
                    looseLids.remove(l);
                } else {
                    
                    for (Cup c : cups) {
                        if (c.hasLid() && c.getLid().getId() == l.getId()) {
                            c.removeLid();
                            break;
                        }
                    }
                }
    
                l.makeInvisible();
                stackItems.remove(i);
    
                rebuildCupsAndLooseLids();
                redraw();
                return;
            }
        }
    
        showMsg("No hay tapas para quitar.");
    }
    
    /**
     * Manage lid- Requisito 3
     */
    public void removeLid(int id) {
        for (int i = 0; i < looseLids.size(); i++) {
            if (looseLids.get(i).getId() == id) {
                Lid l = looseLids.remove(i);
                l.makeInvisible();
                stackItems.remove(l);
                redraw();
                return;
            }
        }

        for (Cup c : cups) {
            if (c.hasLid() && c.getLid().getId() == id) {
                Lid l = c.getLid();
                l.makeInvisible();
                stackItems.remove(l);
                c.removeLid();
                redraw();
                return;
            }
        }
    }
    
    
    /**
     * Reorganize tower- requisito 4 y 5
     */
    public void orderTower() {

        for (int i = 0; i < cups.size() - 1; i++) {
            for (int j = 0; j < cups.size() - 1 - i; j++) {
    
                if (cups.get(j).getId() > cups.get(j + 1).getId()) {
    
                    Cup temp = cups.get(j);
                    cups.set(j, cups.get(j + 1));
                    cups.set(j + 1, temp);
                }
            }
        }
    
        rebuildStackItems();
        redraw();
    }
    
    /**
     * Reorganize tower- requisito 4 y 5
     */
    public void reverseTower() {
        Collections.reverse(cups);
        rebuildStackItems();
        redraw();
    }
    
    /**
     * Consult information- Requisito 6 y 7
     */
    public int height() {
        int h = 0;
        for (Cup c : cups) {
            h += c.getPixelHeight();
            if (c.hasLid()) h += c.getLid().getPixelHeight();
        }
        for (Lid l : looseLids) h += l.getPixelHeight();
        return h;
    }
    
    /**
     * Consult information- Requisito 6 y 7
     */
    public String[][] stackingItems() {
        String[][] info = new String[stackItems.size()][2];
        for (int i = 0; i < stackItems.size(); i++) {
            info[i][0] = stackItems.get(i).getType();
            info[i][1] = "" + stackItems.get(i).getId();
        }
        return info;
    }
    
    /**
     * Set visibility- Requisito 8 
     */
    public void makeVisible() { 
        visible = true; 
        redraw(); 
    }
    
    /**
     * Set visibility- Requisito 8 
     */
    public void makeInvisible() { 
        visible = false;
        for (Cup c : cups){
            c.makeInvisible();
        }
        for (Lid l : looseLids){
            l.makeInvisible();
        } 
    }
    
    /**
     * Exit simulator-Requisito 9
     */
    public void exit() { 
        makeInvisible(); 
        cups.clear(); 
        looseLids.clear(); 
        stackItems.clear();
    }
    
    /**
     * Reorganize Tower-Requisito 11 y 12
     */
    public void swap(String o1, String o2) {
        StackItem item1 = null, item2 = null;
        for (StackItem s : stackItems) {
            if ((s.getType() + "," + s.getId()).equals(o1)){
                item1 = s;
            }
            if ((s.getType() + "," + s.getId()).equals(o2)){ 
                item2 = s;
            }
        }
        
        if (item1 == null || item2 == null){ 
            return;
        }

        int pos1 = stackItems.indexOf(item1);
        int pos2 = stackItems.indexOf(item2);

        Collections.swap(stackItems, pos1, pos2);
        rebuildCupsAndLooseLids();
        redraw();
    }

    /**
     * Reorganize Tower-Requisito 11 y 12
     */
    public void cover() {
        for (Cup c : cups) {
            if (!c.hasLid()) {
                Lid lid = new Lid(c.getId(), c.getWidthCm(), c.getColor());
                c.putLid(lid);
                int pos = stackItems.indexOf(c);
                stackItems.add(pos + 1, lid);
            }
        }
        redraw();
    }

    
    /**
     * Consult Information -Requisito 13
     */
    public String[][] swapToReduce() {
        int alturaOriginal = height();
        for (int i = 0; i < stackItems.size(); i++) {
            for (int j = i + 1; j < stackItems.size(); j++) {
                Collections.swap(stackItems, i, j);
                rebuildCupsAndLooseLids();
                if (height() < alturaOriginal) {
                    String[][] res = {{stackItems.get(j).getType() + "," + stackItems.get(j).getId(),
                                        stackItems.get(i).getType() + "," + stackItems.get(i).getId()}};
                    Collections.swap(stackItems, i, j);
                    rebuildCupsAndLooseLids();
                    return res;
                }
                Collections.swap(stackItems, i, j);
                rebuildCupsAndLooseLids();
            }
        }
        return new String[0][0];
    }

    // ===================== Métodos privados =====================
    private Cup findCup(int id) {
        for (Cup c : cups){ 
            if (c.getId() == id){ 
                return c;
            }
        }
        return null;
    }

    private int generateUniqueLidId() {
        int id = 1;
        HashSet<Integer> usedIds = new HashSet<>();
        for (Cup c : cups) {
            usedIds.add(c.getId());
            if (c.hasLid()){ 
                usedIds.add(c.getLid().getId());
            }
        }
        
        for (Lid l : looseLids) {
            usedIds.add(l.getId());
        }
        
        while (usedIds.contains(id)){
            id++;
        }
        return id;
    }

    private void rebuildCupsAndLooseLids() {
        ArrayList<Cup> newCups = new ArrayList<>();
        ArrayList<Lid> newLooseLids = new ArrayList<>();
        for (StackItem item : stackItems) {
            if (item instanceof Cup){ 
                newCups.add((Cup)item);
            } else if (item instanceof Lid) {
                boolean isLoose = true;
                for (Cup c : newCups) {
                    if (c.hasLid() && c.getLid().getId() == item.getId()){ 
                        isLoose = false;
                    }
                }
                
                if (isLoose) {
                    newLooseLids.add((Lid)item);
                }
            }
        }
        cups = newCups;
        looseLids = newLooseLids;
    }

    private void rebuildStackItems() {
        stackItems.clear();
        for (Cup c : cups) {
            stackItems.add(c);
            if (c.hasLid()){ 
                stackItems.add(c.getLid());
            }
        }
        stackItems.addAll(looseLids);
    }

    private void redraw() {
        if (!visible) return;
        rebuildStackItems();
        int baseX = 50, currentY = 30;
        for (Cup c : cups) {
            c.draw(baseX, currentY);
            if (c.hasLid()){ 
                c.getLid().draw(baseX, currentY - c.getLid().getPixelHeight());
            }
            currentY += c.getPixelHeight();
        }
        
        for (Lid l : looseLids) {
            l.draw(baseX, currentY);
            currentY += l.getPixelHeight();
        }
    }
    
    private void showMsg(String msg) {
        if (visible) {
            JOptionPane.showMessageDialog(null, msg);
        }
    }
}