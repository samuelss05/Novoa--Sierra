public class StackItem {
    protected int id;
    protected int widthCm;
    protected String color;

    public StackItem(int id, int widthCm, String color){
        this.id = id;
        this.widthCm = widthCm;
        this.color = color;
    }

    public int getId(){
        return id; 
    }
    
    public int getWidthCm(){ 
        return widthCm; 
    }
    
    public String getColor(){ 
        return color; 
    }
    
    public int getPixelWidth(){ 
        return widthCm * 5; 
    }
    
    public int getPixelesPorCm(){
        return 5; 
    }
    
    public int getPixelHeight(){ 
        return 5; 
    } 

    public String getType(){
        return "item"; 
    }

    public void draw(int x, int y){
        
    }
    
    public void makeVisible(){
        
    }
    
    public void makeInvisible(){
    
    }
}