public class Lid extends StackItem {
    private Rectangle body;
    private static final int HEIGHT_CM = 1;

    public Lid(int id, int widthCm, String color){
        super(id, widthCm, color);
    }

    @Override
    public String getType(){ 
        return "lid"; 
    }

    public int getPixelHeight(){ 
        return HEIGHT_CM * getPixelesPorCm(); 
    }

    public void draw(int x, int y){
        if(body!=null) {            
            body.makeInvisible();
        }
        body = new Rectangle();
        body.changeColor(color);
        body.changeSize(getPixelHeight(), getPixelWidth());
        body.moveHorizontal(x);
        body.moveVertical(y);
        body.makeVisible();
    }

    public void makeInvisible(){
        if(body!=null){ 
            body.makeInvisible();
        }
    }
}