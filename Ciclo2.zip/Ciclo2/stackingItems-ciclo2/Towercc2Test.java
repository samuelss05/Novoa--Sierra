import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Towercc2Test - Casos de prueba de unidad para Tower
 * Todos los tests en modo invisible (tower.makeInvisible())
 * Cada test documenta:
 * - Qué debería hacer
 * - Qué no debería hacer
 * Nombres de pruebas con iniciales NS
 */
public class Towercc2Test {

    private Tower tower;

    @BeforeEach
    public void setup() {
        tower = new Tower(50, 200);
        tower.makeInvisible();
    }

    @Test
    public void NS_pushCup() {
        tower.pushCup(1, 10, 20, "red");
        String[][] items = tower.stackingItems();
        assertEquals(1, items.length);
        assertEquals("cup", items[0][0]);
        assertEquals("1", items[0][1]);

        // Agregar otra taza con mismo ID: se agrega como otra instancia
        tower.pushCup(1, 10, 20, "red");
        assertEquals(2, tower.stackingItems().length);
    }

    @Test
    public void NS_pushLooseLid() {
        tower.pushLid(null, "green", 5);
        String[][] items = tower.stackingItems();
        assertEquals(1, items.length);
        assertEquals("lid", items[0][0]);

        // No se asigna a taza automáticamente
        boolean cupAssigned = false;
        for (String[] item : items) {
            if (item[0].equals("cup")) cupAssigned = true;
        }
        assertFalse(cupAssigned);
    }

    @Test
    public void NS_pushLidToCup() {
        tower.pushCup(2, 8, 15, "blue");
        tower.pushLid(2, "blue", 8);

        String[][] items = tower.stackingItems();
        boolean lidExists = false;
        for (int i = 0; i < items.length; i++) {
            if (items[i][0].equals("cup") && items[i][1].equals("2")) {
                if (i + 1 < items.length && items[i + 1][0].equals("lid")) {
                    lidExists = true;
                }
            }
        }
        assertTrue(lidExists);

        int lengthBefore = items.length;
        tower.pushLid(999, "blue", 8);
        assertEquals(lengthBefore, tower.stackingItems().length);
    }

    @Test
    public void NS_popCup() {
        tower.pushCup(3, 6, 12, "yellow");
        tower.pushLid(3, "yellow", 6);
        tower.popCup();
        assertEquals(0, tower.stackingItems().length);

        tower.pushCup(4, 5, 10, "pink");
        tower.popCup();
        assertEquals(0, tower.stackingItems().length);
    }

    @Test
    public void NS_popLid() {
        tower.pushCup(5, 7, 14, "orange");
        tower.pushLid(5, "orange", 7);
        tower.popLid();

        String[][] items = tower.stackingItems();
        boolean lidExists = false;
        for (int i = 0; i < items.length; i++) {
            if (items[i][0].equals("cup") && items[i][1].equals("5")) {
                if (i + 1 < items.length && items[i + 1][0].equals("lid")){ 
                    lidExists = true;
                }
            }
        }
        assertFalse(lidExists);

        tower.popLid();
        assertEquals(0, tower.stackingItems().length);
    }

    @Test
    public void NS_removeCup() {
        tower.pushCup(6, 9, 18, "pink");
        tower.removeCup(6);
        boolean cupExists = false;
        for (String[] item : tower.stackingItems()) {
            if (item[0].equals("cup") && item[1].equals("6")){ 
                cupExists = true;
            }
        }
        assertFalse(cupExists);

        tower.pushCup(7, 5, 10, "cyan");
        tower.pushCup(8, 6, 12, "magenta");
        tower.removeCup(7);
        boolean cup8Exists = false;
        for (String[] item : tower.stackingItems()) {
            if (item[0].equals("cup") && item[1].equals("8")){ 
                cup8Exists = true;
            }
        }
        assertTrue(cup8Exists);
    }

    @Test
    public void NS_removeLid() {
        tower.pushLid(null, "black", 4);
        int lidId = Integer.parseInt(tower.stackingItems()[0][1]);
        tower.removeLid(lidId);
        assertEquals(0, tower.stackingItems().length);

        tower.pushCup(9, 5, 10, "white");
        tower.pushLid(9, "white", 5);
        tower.removeLid(lidId);
        boolean lid9Exists = false;
        String[][] items = tower.stackingItems();
        for (String[] item : items) {
            if (item[0].equals("lid") && item[1].equals("9")) {
                lid9Exists = true;
            }
        }
        assertTrue(lid9Exists);
    }

    @Test
    public void NS_swapItems() {
        tower.pushCup(10, 5, 10, "white");
        tower.pushCup(11, 6, 12, "gray");
        tower.swap("cup,10", "cup,11");

        String[][] items = tower.stackingItems();
        assertEquals("11", items[0][1]);
        assertEquals("10", items[1][1]);

        tower.swap("cup,999", "cup,10"); 
    }

    @Test
    public void NS_cover() {
        tower.pushCup(12, 10, 20, "red");
        tower.cover();

        String[][] items = tower.stackingItems();
        boolean lidExists = false;
        for (int i = 0; i < items.length; i++) {
            if (items[i][0].equals("cup") && items[i][1].equals("12")) {
                if (i + 1 < items.length && items[i + 1][0].equals("lid")) {
                    lidExists = true;
                }
            }
        }
        assertTrue(lidExists);

        int countBefore = tower.stackingItems().length;
        tower.cover();
        assertEquals(countBefore, tower.stackingItems().length);
    }

    @Test
    public void NS_orderReverseTower() {
        tower.pushCup(13, 5, 10, "blue");
        tower.pushCup(14, 5, 10, "green");
        tower.orderTower();
        String[][] items = tower.stackingItems();
        assertEquals("14", items[0][1]);
        tower.reverseTower();
        items = tower.stackingItems();
        assertEquals("13", items[0][1]);

        assertEquals(2, tower.stackingItems().length);
    }

    @Test
    public void NS_heightCalculation() {
        tower.pushCup(15, 5, 10, "cyan");
        tower.pushLid(15, "cyan", 5);
        int expectedHeight = 10 * 5 + 1 * 5; 
        assertEquals(expectedHeight, tower.height());

        tower.popCup();
        assertEquals(0, tower.height());
    }

    @Test
    public void NS_swapToReduce() {
        tower.pushCup(16, 5, 20, "red");
        tower.pushCup(17, 5, 10, "blue");
        tower.pushLid(16, "red", 5);
        tower.pushLid(17, "blue", 5);

        String[][] swap = tower.swapToReduce();
        assertNotNull(swap);

        Tower emptyTower = new Tower(50, 200);
        emptyTower.makeInvisible();
        assertEquals(0, emptyTower.swapToReduce().length);
    }
    
    
    //PUNTO 4
    /**
    * - NS_pushCup: agregar taza, no duplicar ID
    - NS_pushLidToCup: agregar tapa a taza existente, no a taza inexistente
    - NS_pushLooseLid: agregar tapa suelta, no asignarla automáticamente
    - NS_popCup: quitar última taza y tapa, no falla si sin tapa
    - NS_popLid: quitar tapa, sueltas primero, no falla si no hay tapas
    - NS_removeCup: quitar taza por ID, no afectar otras tazas/tapas
    - NS_removeLid: quitar tapa por ID (sueltas o de taza), no afectar otras
    - NS_swapItems: intercambiar elementos, no intercambiar inexistentes
    - NS_cover: cubrir tazas sin tapa, no duplicar tapas
    - NS_orderReverseTower: ordenar/revertir, no eliminar ni cambiar IDs
    - NS_heightCalculation: calcular altura correctamente, no sumar invisibles
    - NS_swapToReduce: encontrar swap que reduzca altura, no intercambiar si no hay reducción
     */
   
}