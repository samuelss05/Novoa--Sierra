public class Cup extends StackItem {
    private int heightCm;
    private Lid lid;
    private Rectangle left, right, base;
    private static final int GROSOR = 5;

    public Cup(int id, int widthCm, int heightCm, String color){
        super(id, widthCm, color);
        this.heightCm = heightCm;
    }

    public boolean hasLid(){ 
        return lid != null; 
    }
    
    public Lid getLid(){ 
        return lid; 
    }
    
    public void putLid(Lid l){ 
        lid = l; 
    }
    
    public void removeLid(){ 
        lid = null; 
    }

    @Override
    public String getType(){ 
        return "cup"; 
    }

    public int getPixelHeight(){ 
        return heightCm * getPixelesPorCm(); 
    }

    public void draw(int x, int y){
        if(left!=null) {            
            left.makeInvisible();
        }
        if(right!=null){ 
            right.makeInvisible();
        }   
        if(base!=null){ 
            base.makeInvisible();
        }

        left = new Rectangle();
        right = new Rectangle();
        base = new Rectangle();

        left.changeColor(color);
        right.changeColor(color);
        base.changeColor(color);

        left.changeSize(getPixelHeight(), GROSOR);
        right.changeSize(getPixelHeight(), GROSOR);
        base.changeSize(GROSOR, getPixelWidth());

        left.moveHorizontal(x);
        left.moveVertical(y);

        right.moveHorizontal(x + getPixelWidth() - GROSOR);
        right.moveVertical(y);

        base.moveHorizontal(x);
        base.moveVertical(y + getPixelHeight() - GROSOR);

        left.makeVisible();
        right.makeVisible();
        base.makeVisible();

        if(hasLid()){
            Lid l = getLid();
            l.draw(x, y - l.getPixelHeight());
        }
    }

    public void makeInvisible(){
        if(left!=null) {            
            left.makeInvisible();
        }
        if(right!=null) {
            right.makeInvisible();
        }
        if(base!=null){ 
            base.makeInvisible();
        }
        if(lid!=null) {
            lid.makeInvisible();
        }
    }
}