public class AcceptanceTest {
    public static void main(String[] args) {
        Tower tower = new Tower(50, 200);
        tower.makeVisible();

        // Prueba 1: Cover
        tower.pushCup(1, 10, 15, "red");
        tower.pushCup(2, 10, 15, "blue");
        tower.pushLid(null, "blue", 10); 
        tower.cover(); 
        System.out.println("Prueba 1: cover realizada");

        // Prueba 2: swapToReduce
        tower.pushCup(3, 5, 20, "green");
        tower.pushCup(4, 5, 10, "yellow");
        tower.pushLid(3, "green", 5);
        tower.pushLid(4, "yellow", 5);

        String[][] swap = tower.swapToReduce();
        if(swap.length > 0) {
            System.out.println("Prueba 2: swap recomendado: " + swap[0][0] + " <-> " + swap[0][1]);
        } else {
            System.out.println("Prueba 2: no hay swap que reduzca altura");
        }
    }
}