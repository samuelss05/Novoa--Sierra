/**
 * La clase Lid representa la tapa de una taza dentro del simulador de apilamiento.
 * Novoa - Sierra
 * 
 */

public class Lid {
    /**
     * Definicion de atributos 
     */
    private int id;
    private int widthCm;
    private String color;
    private Rectangle body;

    private static final int Pixeles_Por_Cm = 5;
    private static final int HEIGHT_CM = 1;
    
    /**
     * Constructor
     */
    public Lid(int id, int widthCm, String color) {
        this.id = id;
        this.widthCm = widthCm;
        this.color = color;
    }
    
    /**
     * Retorna el identificador de la tapa 
     */
    public int getId() {
        return id;
    }
    
    /**
     * Retorna la altura de la tapa en pixeles para su visualizacion
     */
    public int getPixelHeight() {
        return HEIGHT_CM * Pixeles_Por_Cm;
    }
    
    /**
     * Retorna el ancho de la tapa en pixeles para su visualizacion 
     */
    public int getPixelWidth() {
        return widthCm * Pixeles_Por_Cm;
    }
    
    /**
     * Dibuja la tapa sobre la taza correspondiente segun su id 
     */
    public void draw(int x, int yTop) {
        if (body != null){ 
            body.makeInvisible();
        }

        body = new Rectangle();
        body.changeColor(color);
        body.changeSize(getPixelHeight(), getPixelWidth());
        body.moveHorizontal(x);
        body.moveVertical(yTop);
        body.makeVisible();
    }
    
    /**
     * Hace invisible la tapa
     */
    public void makeInvisible() {
        if (body != null){
            body.makeInvisible();
        }
    }
}
