/**
 * La clase Cup representa una taza dentro del simulador de apilamiento
 * Novoa - Sierra
 */
public class Cup {
    /**
     * Definicion de atributos 
     */
    private int id;
    private int widthCm;
    private int heightCm;
    private String color;
    private Lid lid;

    private Rectangle left;
    private Rectangle right;
    private Rectangle base;

    private static final int Pixeles_Por_CM = 5;  // convercion de cm a pixeles 
    private static final int Grosor_Pared_Pixeles = 5;
    
    /**
     * Constructor
     */
    
    public Cup(int id, int widthCm, int heightCm, String color) {
        this.id = id;
        this.widthCm = widthCm;
        this.heightCm = heightCm;
        this.color = color;
    }
    /**
     * Retorna el identificador de la taza
     */
    public int getId() {
        return id;
    }
    
    /**
     * Retorna el ancho de la taza  
    */
    
    public int getWidthCm() {
        return widthCm;
    }
    
    /**
     * Retorna el color de la taza
     */
    public String getColor() {
        return color;
    }
    
    /**
     * Retorna la altura de la taza en pixeles para su visualizacion
     */
    public int getPixelHeight() {
        return heightCm * Pixeles_Por_CM;
    }
    
    /**
     * Retorna el ancho de la taza en pixeles para su visualizacion 
     */
    public int getPixelWidth() {
        return widthCm * Pixeles_Por_CM;
    }
    
    /**
     * Indica si la taza tiene una tapa asociada 
     */

    public boolean hasLid() {
        return lid != null;
    }
    
    /**
     * Retorna la tapa asociada a la taza 
     */
    public Lid getLid() {
        return lid;
    }
    /**
     * Asocia una tapa a la taza
     */
    public void putLid(Lid lid) {
        this.lid = lid;
    }
    
    /**
     * Remueve la tapa asocaiada a la taza dejandola destapada
     */

    public void removeLid() {
        this.lid = null;
    }
    
    /**
     * Dibuja graficamente la taza en el canvas
     */
    public void draw(int x, int yTop) {
        int h = getPixelHeight();
        int w = getPixelWidth();
        if (left != null) {
            left.makeInvisible();
        }
        if (right != null){ 
            right.makeInvisible();
        }
        if (base != null) {
            base.makeInvisible();
        }
        left = new Rectangle();
        right = new Rectangle();
        base = new Rectangle();

        left.changeColor(color);
        right.changeColor(color);
        base.changeColor(color);

        left.changeSize(h, Grosor_Pared_Pixeles);
        right.changeSize(h, Grosor_Pared_Pixeles);
        base.changeSize(Grosor_Pared_Pixeles, w);

        left.moveHorizontal(x);
        left.moveVertical(yTop);

        right.moveHorizontal(x + w - Grosor_Pared_Pixeles);
        right.moveVertical(yTop);

        base.moveHorizontal(x);
        base.moveVertical(yTop + h - Grosor_Pared_Pixeles);

        left.makeVisible();
        right.makeVisible();
        base.makeVisible();
    }
    
    /**
     * Oculta la representacion grafia de la taza y la tapa si existe 
     */
    public void makeInvisible() {
        if (left != null){ 
            left.makeInvisible();
        }
        if (right != null){ 
            right.makeInvisible();
        }
        if (base != null) {
            base.makeInvisible();
        }
        if (lid != null){ 
            lid.makeInvisible();            
        }
    }
}
