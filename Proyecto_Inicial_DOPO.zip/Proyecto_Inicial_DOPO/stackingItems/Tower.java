import java.util.*;
import javax.swing.*;
/**
 * La clase tower representa la torre de tazas del simulador 
 * 
 * Novoa - Sierra
 */
public class Tower {
    
    /**
     * Definicion de atributos 
     */
    private int width;
    private int maxHeight;
    private boolean visible;

    private ArrayList<Cup> cups;
    private ArrayList<Lid> looseLids;
    
    /**
     * Constructor 
     */
    //requisito 1 - create tower
    public Tower(int width, int maxHeight) {
        this.width = width;
        this.maxHeight = maxHeight;
        this.visible = false;
        cups = new ArrayList<Cup>();
        looseLids = new ArrayList<Lid>();
    }

    // Requisito 2 - manage cup
    /**
     * Agrega una taza a la torre
     */
    public void pushCup(int id, int widthCm, int heightCm, String color) {
        cups.add(new Cup(id, widthCm, heightCm, color));
        redraw();
    }
    
    /**
     * Remueve la taza que esta en la parte superior de la torre 
     */
    public void popCup() {
        if (cups.size() > 0) {
            Cup c = cups.remove(cups.size() - 1);
            c.makeInvisible();
            redraw();
        } else {
            showMsg("No hay tazas para quitar.");
        }
    }
    
    /**
     * Remueve una taza especifica de la torre por su id 
     */
    public void removeCup(int id) {
        Cup c = findCup(id);
        if (c != null) {
            c.makeInvisible();
            cups.remove(c);
            redraw();
        } else {
            showMsg("No existe la taza " + id);
        }
    }

    // Requisito 3 - manage lid
    /**
     * Coloca una tapa sobre la taza indicada 
     */
    public void pushLid(int cupId) {
        Cup c = findCup(cupId);
        if (c == null) {
            showMsg("No existe la taza " + cupId);
            return;
        }

        Lid lid = new Lid(cupId, c.getWidthCm(), c.getColor());

        if (!c.hasLid()) {
            c.putLid(lid);
        } else {
            looseLids.add(lid); 
        }
        redraw();
    }
    
    /**
     * Remueve la ultima tapa suelta de la torre 
     */
    public void popLid() {
        if (looseLids.size() > 0) {
            Lid l = looseLids.remove(looseLids.size() - 1);
            l.makeInvisible();
            redraw();
        } else {
            showMsg("No hay tapas sueltas para quitar.");
        }
    }
    
    /**
     * Remueve una tapa especifica por su identificador 
     */
    public void removeLid(int id) {
        for (int i = 0; i < looseLids.size(); i++) {
            if (looseLids.get(i).getId() == id) {
                looseLids.get(i).makeInvisible();
                looseLids.remove(i);
                redraw();
                return;
            }
        }
        for (Cup c : cups) {
            if (c.hasLid() && c.getLid().getId() == id) {
                c.getLid().makeInvisible();
                c.removeLid();
                redraw();
                return;
            }
        }
        showMsg("No existe la tapa " + id);
    }

    // Requisitos 4 y 5 - reorganize tower (implementación simple para ciclo 1)
    /**
     * Ordena la torre de tazas
     */
    public void orderTower() {
        Collections.reverse(cups);
        redraw();
    }
    
    /**
     * Invierte el orden de las tazas en la torre 
     */
    public void reverseTower() {
        Collections.reverse(cups);
        redraw();
    }

    // Requisito 6 - height
    /**
     * Calcula la altura total de la torre incluyendo tapas puestas y sueltas
     */
    public int height() {
        int h = 0;
        for (Cup c : cups) {
            if (c.hasLid()){ 
                h += c.getLid().getPixelHeight();
                h += c.getPixelHeight();
            }
        }
        for (Lid l : looseLids) {
            h += l.getPixelHeight();
        }
        return h;
    }

    // Requisito 7 - stacking items
    /**
     * Devuelve un arreglo con la informacion de los elementos de la torre 
     */
    public String[][] stackingItems() {
        String[][] info = new String[cups.size() + looseLids.size()][2];
        int i = 0;

        for (Cup c : cups) {
            info[i][0] = "cup";
            info[i][1] = "" + c.getId();
            i++;
        }

        for (Lid l : looseLids) {
            info[i][0] = "lid";
            info[i][1] = "" + l.getId();
            i++;
        }

        return info;
    }

    // Requisito 8 - visibility
    /**
     * Hace visible toda la torre en el canvas 
     */
    public void makeVisible() {
        visible = true;
        redraw();
    }
    
    /**
     * Oculta toda la torre en el canvas 
     */
    public void makeInvisible() {
        visible = false;
        for (Cup c : cups){
            c.makeInvisible();
        }
        for (Lid l : looseLids){
            l.makeInvisible();
        }
    }

    // Requisito 9 - exit
    /**
     * Vacia la torre y oculta todos los elementos 
     */
    public void exit() {
        makeInvisible();
        cups.clear();
        looseLids.clear();
    }
    
    /**
     * Metodo de prueba retorna siempre true 
     */
    public boolean ok() {
        return true;
    }

    // ================= PRIVADOS =================
    
    /**
     * Busca una taza por su id 
     */
    private Cup findCup(int id) {
        for (Cup c : cups) {
            if (c.getId() == id) {
                return c;
            }
        }
        return null;
    }
    
    /**
     * Redibuja toda la torre en el canvas, calculando la posicion de cada taza y tapa 
     */
    private void redraw() {
        if (!visible) {
            return;
        }

        int baseX = 50;
        int currentY = 30;

        for (Cup c : cups) {
            c.draw(baseX, currentY);

            if (c.hasLid()) {
                Lid l = c.getLid();
                int yLid = currentY - l.getPixelHeight();
                l.draw(baseX, yLid);
                currentY += l.getPixelHeight();
            }

            currentY += c.getPixelHeight();
        }

        for (Lid l : looseLids) {
            l.draw(baseX, currentY);
            currentY += l.getPixelHeight();
        }
    }
    
    /**
     * Muestra un mensaje de alerta al usuario usando JOptionPane
     */
    private void showMsg(String msg) {
        if (visible) {
            JOptionPane.showMessageDialog(null, msg);
        }
    }
}
