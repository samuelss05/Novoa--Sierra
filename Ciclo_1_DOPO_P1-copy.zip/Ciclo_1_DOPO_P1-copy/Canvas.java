import javax.swing.*;
import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.util.*;

/**
 * Canvas simplificado según el diagrama de clases.
 * Permite dibujar rectángulos en la pantalla.
 */
public class Canvas {

    private static Canvas canvasSingleton;
    private JFrame frame;
    private JPanel canvasPanel;
    private Graphics2D graphic;
    private Color backgroundColour;
    private Image canvasImage;
    private ArrayList<Object> objects;
    private Map<Object, ShapeDescription> shapes;

    public Canvas() {
        frame = new JFrame("Canvas Demo");
        canvasPanel = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (graphic != null) {
                    graphic = (Graphics2D) g;
                    redraw();
                }
            }
        };
        frame.setContentPane(canvasPanel);
        canvasPanel.setPreferredSize(new Dimension(300, 300));
        backgroundColour = Color.white;
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        objects = new ArrayList<>();
        shapes = new HashMap<>();

        setVisible(true);
    }

    public static Canvas getCanvas() {
        if (canvasSingleton == null) {
            canvasSingleton = new Canvas();
        }
        return canvasSingleton;
    }

    public void setVisible(boolean visible) {
        frame.setVisible(visible);
    }

    public void draw(Object referenceObject, String color, Shape shape) {
        objects.remove(referenceObject);
        objects.add(referenceObject);
        shapes.put(referenceObject, new ShapeDescription(shape, color));
        canvasPanel.repaint();
    }

    public void erase(Object referenceObject) {
        objects.remove(referenceObject);
        shapes.remove(referenceObject);
        canvasPanel.repaint();
    }

    private void redraw() {
        if (graphic == null) return;
        graphic.setColor(backgroundColour);
        graphic.fillRect(0, 0, canvasPanel.getWidth(), canvasPanel.getHeight());

        for (Object obj : objects) {
            shapes.get(obj).draw(graphic);
        }
    }

    private class ShapeDescription {
        private Shape shape;
        private String colorString;

        public ShapeDescription(Shape shape, String color) {
            this.shape = shape;
            this.colorString = color;
        }

        public void draw(Graphics2D graphic) {
            graphic.setColor(switch (colorString.toLowerCase()) {
                case "red" -> Color.red;
                case "blue" -> Color.blue;
                case "green" -> Color.green;
                case "yellow" -> Color.yellow;
                case "magenta" -> Color.magenta;
                case "black" -> Color.black;
                default -> Color.black;
            });
            graphic.fill(shape);
        }
    }
}
