import java.awt.geom.Rectangle2D;

public class Rectangle {

    private int width;
    private int height;
    private int xPosition;
    private int yPosition;
    private String color;

    public Rectangle(int width, int height, int xPosition, int yPosition, String color) {
        this.width = width;
        this.height = height;
        this.xPosition = xPosition;
        this.yPosition = yPosition;
        this.color = color;
    }

    public int getWidth() { return width; }
    public int getHeight() { return height; }
    public int getX() { return xPosition; }
    public int getY() { return yPosition; }
    public String getColor() { return color; }

    public void draw() {
        Rectangle2D.Double shape = new Rectangle2D.Double(xPosition, yPosition, width, height);
        Canvas.getCanvas().draw(this, color, shape);
    }

    public void makeVisible() {
        draw();
    }

    public void makeInvisible() {
        Canvas.getCanvas().erase(this);
    }
}
