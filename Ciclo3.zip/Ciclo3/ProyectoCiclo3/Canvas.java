import javax.swing.*;
import java.awt.*;
import java.util.*;

public class Canvas {
    private static Canvas canvasSingleton;

    public static Canvas getCanvas() {
        if(canvasSingleton == null) {
            canvasSingleton = new Canvas("Tower Demo", 800, 600, Color.white);
            canvasSingleton.setVisible(true);
        }
        return canvasSingleton;
    }

    private JFrame frame;
    private CanvasPane canvas;
    private Graphics2D graphic;
    private Color backgroundColour;
    private Image canvasImage;
    private ArrayList<Object> objects;
    private HashMap<Object, ShapeDescription> shapes;

    private Canvas(String title, int width, int height, Color bgColour) {
        frame = new JFrame();
        canvas = new CanvasPane();
        frame.setContentPane(canvas);
        frame.setTitle(title);
        canvas.setPreferredSize(new Dimension(width, height));
        backgroundColour = bgColour;
        frame.pack();
        objects = new ArrayList<>();
        shapes = new HashMap<>();
    }

    public void setVisible(boolean visible) {
        if(graphic == null) {
            Dimension size = canvas.getSize();
            canvasImage = canvas.createImage(size.width, size.height);
            graphic = (Graphics2D)canvasImage.getGraphics();
            graphic.setColor(backgroundColour);
            graphic.fillRect(0, 0, size.width, size.height);
            graphic.setColor(Color.black);
        }
        frame.setVisible(visible);
    }

    public void draw(Object referenceObject, String color, Shape shape) {
        if(!objects.contains(referenceObject)) objects.add(referenceObject);
        shapes.put(referenceObject, new ShapeDescription(shape, color));
        redraw();
    }

    public void erase(Object referenceObject) {
        objects.remove(referenceObject);
        shapes.remove(referenceObject);
        redraw();
    }

    private void redraw() {
        eraseAll();
        for(Object obj : objects) {
            shapes.get(obj).draw(graphic);
        }
        canvas.repaint();
    }

    private void eraseAll() {
        Color original = graphic.getColor();
        graphic.setColor(backgroundColour);
        Dimension size = canvas.getSize();
        graphic.fillRect(0, 0, size.width, size.height);
        graphic.setColor(original);
    }

    private class CanvasPane extends JPanel {
        public void paint(Graphics g) {
            g.drawImage(canvasImage, 0, 0, null);
        }
    }

    private class ShapeDescription {
        private Shape shape;
        private String colorString;

        public ShapeDescription(Shape shape, String color) {
            this.shape = shape;
            this.colorString = color;
        }

        public void draw(Graphics2D graphic) {
            switch(colorString.toLowerCase()) {
                case "red": graphic.setColor(Color.red); break;
                case "black": graphic.setColor(Color.black); break;
                case "blue": graphic.setColor(Color.blue); break;
                case "yellow": graphic.setColor(Color.yellow); break;
                case "green": graphic.setColor(Color.green); break;
                case "magenta": graphic.setColor(Color.magenta); break;
                default: graphic.setColor(Color.black);
            }
            graphic.fill(shape);
        }
    }
    // En Canvas.java
    public int getWidth() {
        return canvas.getWidth();
    }
}