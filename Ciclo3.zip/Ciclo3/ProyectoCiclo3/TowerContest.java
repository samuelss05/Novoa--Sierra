import java.util.*;
import java.util.stream.Collectors;
import javax.swing.JOptionPane;
public class TowerContest {

    private Map<String, Integer> memoAportes = new HashMap<>();

    /**
     * Requisito 14: Resuelve el problema principal.
     */
    public String solve(int n, int h) {

        if (!estaEnRango(n, h) || esCasoImposible(n, h)) {
            return "impossible";
        }

        if (h == alturaMinima(n)) return generarOrdenDescendente(n);
        if (h == alturaMaxima(n)) return generarOrdenAscendente(n);
        if (h == (2*n)+1) return casoEspecial(n);

        return buscarAcomodo(n, h);
    }

    // METODOS DE APOYO 

    private int alturaMinima(int n) {
        return 2 * n - 1;
    }

    private int alturaMaxima(int n) {
        return n * n;
    }

    private boolean estaEnRango(int n, int h) {
        return h >= alturaMinima(n) && h <= alturaMaxima(n);
    }    

    private boolean esCasoImposible(int n, int h) {
        boolean imposible = false;
        if (h == (n*n)-2){
            imposible = true;
        }
        return imposible;
    }
    
    /**
     * Organiza las tazas de altura mínima a altura máxima (Orden Ascendente)
     */
    private String generarOrdenAscendente(int n) {
        String res = "";
        for (int i = 0; i < n; i++) {
            res += (2 * (i + 1) - 1) + (i == n - 1 ? "" : " ");
        }
        return res;
    }

    /**
     * Organiza las tazas de altura máxima a altura mínima (Orden Descendente)
     */
    private String generarOrdenDescendente(int n) {
        String res = "";
        for (int i = 0; i < n; i++) {
            res += (2 * (n - i) - 1) + (i == n - 1 ? "" : " ");
        }
        return res;
    }
    
    /**
     * Caso Especial para h = 2n + 1
     */
    private String casoEspecial(int n) {
        int[] torre = new int[n];
        boolean[] usadas = new boolean[n + 1];
        
        int masGrande = 2 * n - 1;
        torre[0] = masGrande;
        usadas[n] = true; 

        torre[1] = 3;
        usadas[2] = true;

        int idx = 2;
        for (int i = n; i >= 1; i--) {
            if (!usadas[i]) {
                torre[idx] = 2 * i - 1;
                idx++;
            }
        }

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) {
            sb.append(torre[i]).append(i == n - 1 ? "" : " ");
        }
        return sb.toString();
    }

    
    private String buscarAcomodo(int n, int h) {
        List<Integer> tazas = new ArrayList<>();
        for (int i = 1; i <= n; i++) tazas.add(2 * i - 1);

        Random rnd = new Random();
        for (int intento = 0; intento < 5000; intento++) {
            Collections.shuffle(tazas, rnd);
            
            if (calcularAltura(tazas) == h) {
                return tazas.stream().map(String::valueOf).collect(Collectors.joining(" "));
            }
        }
        return "impossible";
    }

    private int calcularAltura(List<Integer> tazas) {
        int maxH = 0;
        int baseSuelo = 0;
        int anterior = 0;
        for (int i = 0; i < tazas.size(); i++) {
            int actual = tazas.get(i);
            if (i == 0) {
                baseSuelo = 0;
            } else {
                baseSuelo = (actual < anterior) ? (baseSuelo + 1) : (baseSuelo + anterior);
            }
            maxH = Math.max(maxH, baseSuelo + actual);
            anterior = actual;
        }
        return maxH;
    }

    private boolean encontrarRutaFinal(int n, int hObj, int pos, int hMax, int baseSuelo, int tamAnterior, boolean[] usadas, int[] torre) {
        if (pos == n) {
            return hMax == hObj;
        }

        String estado = pos + "|" + hMax + "|" + baseSuelo + "|" + tamAnterior;
        if (memoAportes.containsKey(estado)) return false;

        boolean buscarDesdeGrande = hObj > (n * n) / 2;

        for (int count = 1; count <= n; count++) {
            int i = buscarDesdeGrande ? (n - count + 1) : count;
            
            if (!usadas[i]) {
                int tam = 2 * i - 1;
                int nuevaBase;

                if (pos == 0) {
                    nuevaBase = 0;
                } else {
                    nuevaBase = (tam < tamAnterior) ? (baseSuelo + 1) : (baseSuelo + tamAnterior);
                }

                int tope = nuevaBase + tam;
                int nuevoMax = Math.max(hMax, tope);    

                if (nuevoMax <= hObj) {
                    torre[pos] = tam;
                    usadas[i] = true;
                    if (encontrarRutaFinal(n, hObj, pos + 1, nuevoMax, nuevaBase, tam, usadas, torre)) return true;
                    usadas[i] = false;
                }
            }
        }

        memoAportes.put(estado, 0); 
        return false;
    }
    
        /**
     * Simulación gráfica siguiendo estrictamente el resultado de solve.
     * @param n Número de tazas.
     * @param h Altura objetivo.
     */
    public void simulate(int n, int h) {
        // 1. Obtenemos la solución lógica del problema
        String resultadoSolve = solve(n, h);
    
        // 2. Verificamos si la solución es posible
        if (resultadoSolve.equals("impossible")) {
            JOptionPane.showMessageDialog(null, 
                "No es posible construir una torre de altura " + h + " con " + n + " tazas.", 
                "Error de Simulación", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }
    
        // 3. Inicializamos el visualizador (Tower)
        // Usamos el constructor de dimensiones para que empiece vacío
        Tower visualizador = new Tower(800, 600); 
        
        // 4. Hacemos visible el simulador
        visualizador.makeVisible();
    
        // 5. Procesamos el String de la solución (ej: "7 3 5 1")
        // Separamos por espacios para obtener cada tamaño de taza
        String[] tamaños = resultadoSolve.split(" ");
        
        try {
            for (String tamStr : tamaños) {
                int tamaño = Integer.parseInt(tamStr);
                
                /*
                 * REGLA DE CONVERSIÓN:
                 * El problema dice: tamaño = 2 * id - 1
                 * Por lo tanto: id = (tamaño + 1) / 2
                 */
                int idParaSimulador = (tamaño + 1) / 2;
    
                // 6. Agregamos la taza al simulador en el orden exacto dado por solve
                visualizador.pushCup(idParaSimulador);
                
                // Opcional: Pequeña pausa para ver cómo se construye la torre
                Thread.sleep(300); 
            }
    
            // 7. Notificación final de éxito
            JOptionPane.showMessageDialog(null, 
                "Simulación completada con éxito.\nOrden: " + resultadoSolve + "\nAltura total: " + h, 
                "Simulación Finalizada", 
                JOptionPane.INFORMATION_MESSAGE);
    
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error durante la simulación: " + e.getMessage());
        }
    }
}