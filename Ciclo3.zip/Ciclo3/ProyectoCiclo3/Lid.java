public class Lid extends StackItem {
    private Rectangle body;
    private static final int HEIGHT_CM = 1;

    public Lid(int id,String color){
        super(id, color);
        body = new Rectangle();
        body.changeSize(5, getPixelWidth());
        body.changeColor(color);
        
        
        
    }

    @Override
    public String getType(){ 
        return "lid"; 
    }
    
    @Override
    public int getPixelHeight(){ 
        return 5; 
    }
    
    @Override
    public int getPixelWidth(){ 
        return 10 * (2*id-1); 
    }
    
    @Override
    public void draw(int x, int y){
        body.changeSize(5, getPixelWidth());
        body.moveTo(x, y);
        makeVisible();
    }

    @Override
    public void makeInvisible(){
        body.makeInvisible();
    }
    
    @Override
    public void makeVisible(){
        body.makeVisible();
    }
}