public class Cup extends StackItem {
    private Lid lid;
    private Rectangle left; 
    private Rectangle right; 
    private Rectangle base;
    private static final int GROSOR = 5;

    public Cup(int id, String color){
        super(id, color);
        left = new Rectangle();
        right = new Rectangle();
        base = new Rectangle();

        left.changeColor(color);
        right.changeColor(color);
        base.changeColor(color);

        left.changeSize(getPixelHeight(), GROSOR);
        right.changeSize(getPixelHeight(), GROSOR);
        base.changeSize(GROSOR, getPixelWidth());
    }

    public boolean hasLid(){ 
        return lid != null; 
    }
    
    public Lid getLid(){ 
        return lid; 
    }
    
    public void putLid(Lid l){ 
        if(lid == null){
            l.color = this.color;
            lid = l;
        }
    }
    
    public void removeLid(){ 
        lid = null; 
    }

    @Override
    public String getType(){ 
        return "cup"; 
    }

    public int getPixelHeight(){ 
        return (2 * id -1) * 10; 
    }
    
    public int getPixelWidth(){ 
        return (2 * id -1) * 10; 
    }
    

    @Override
    public void draw(int x, int y) {
        int w = getPixelWidth();
        int h = getPixelHeight();
    
        // 1. BASE: Ocupa todo el ancho (w) en la parte de abajo.
        base.changeSize(GROSOR, w); 
        base.moveTo(x, y + h - GROSOR); 
    
        // 2. PARED IZQUIERDA: Solo llega hasta donde empieza la base.
        // Su alto real es (Alto Total - 5 de la base).
        left.changeSize(h - GROSOR, GROSOR);
        left.moveTo(x, y);
    
        // 3. PARED DERECHA: Igual que la izquierda, pero al otro lado.
        right.changeSize(h - GROSOR, GROSOR);
        right.moveTo(x + w - GROSOR, y);
    
        makeVisible();
        if(hasLid()) {
            lid.draw(x, y - lid.getPixelHeight());
        }
    }
    
    @Override 
    public void makeInvisible(){
       left.makeInvisible();
        right.makeInvisible();
        base.makeInvisible();
        if(hasLid()) lid.makeInvisible();
    }

    public void makeVisible(){
        left.makeVisible();
        right.makeVisible();
        base.makeVisible();
        if(hasLid()) lid.makeVisible();
    }
}