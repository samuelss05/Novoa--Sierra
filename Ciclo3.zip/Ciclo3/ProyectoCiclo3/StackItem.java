public abstract class StackItem {
    protected int id;
    protected String color;

    public StackItem(int id, String color){
        this.id = id;
        this.color = color;
    }

    public int getId(){
        return id; 
    }
    
    public String getColor(){
        return color;
    }
    
    public abstract int getPixelWidth();
    public abstract int getPixelHeight();
    public abstract void draw(int x, int y);
    public abstract void makeInvisible();
    public abstract void makeVisible();
    public abstract String getType();
}