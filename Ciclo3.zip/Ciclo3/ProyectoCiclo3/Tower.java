import java.util.*;
import javax.swing.*;
import java.util.Random;


public class Tower {

    private int width;
    private int maxHeight;
    private boolean visible;

    private ArrayList<StackItem> stackItems;       

    /**
     * Constructores
     */
    public Tower(int width, int maxHeight) {
        this.width = width;
        this.maxHeight = maxHeight;
        this.visible = false;
        stackItems = new ArrayList<>();
        
    }

    /**
     * Requisito 10
     * Constructor alternativo: crea n tazas iniciales 
     * con mismo color y tamaños crecientes
     */
    public Tower(int cups ) {
        this(600,500);
        
        for (int i = 1; i <= cups; i++) {
            String color = randomColor();
            Cup c = new Cup(i, color);
            stackItems.add(c);
        }
        if(visible){
            redraw();
        }
    }

    /**
     * Manage cup- Requisito 2 
     */
    public void pushCup(int id) {
        String color = randomColor();
        Cup cup = new Cup(id, color);
        stackItems.add(cup);
        
        if(visible){
            redraw();
        }
        
       
    }

    /**
     * Manage cup- Requisito 2 
     */
    public void popCup() {
        for(int i = stackItems.size()-1; i >= 0; i--){
            StackItem item = stackItems.get(i);
            if(item instanceof Cup){
                Cup cup = (Cup) item;
                
                if (cup.hasLid()){
                    Lid laTapa = cup.getLid();
                    laTapa.makeInvisible();
                    stackItems.remove(laTapa);
                    cup.removeLid();
                }
                cup.makeInvisible();
                stackItems.remove(i);
                break;
            }
        }
        if(visible){
            redraw();
        }
    }

    /**
     * Manage cup- Requisito 2 
     */
    public void removeCup(int id) {
        for (int i = 0; i < stackItems.size(); i++){
            StackItem item = stackItems.get(i);
            
            if(item instanceof Cup){
                Cup cup = (Cup) item;
                
                if(cup.getId() == id){
                    if(cup.hasLid()){
                    cup.getLid().makeInvisible();
                    cup.removeLid();
                    }
                    cup.makeInvisible();
                    stackItems.remove(i);
                    break;
                }
            }
        }
        if(visible){
            redraw();
        }
    }

    /**
     * Manage lid- Requisito 3 
     */
    public void pushLid(int id) {
        boolean cupid = false;
        
        for(StackItem item: stackItems){
            
            if(item instanceof Cup){
                Cup cup = (Cup) item;
            
                if(cup.getId() == id){
                    cupid = true;
                    
                    if(!cup.hasLid()){
                        Lid lid = new Lid(id, cup.getColor());
                        cup.putLid(lid);
                    }
                    break;
                }
            }
        }
        
        if(!cupid){
            String color = randomColor();
            Lid lidSuelta = new Lid(id,color);
            stackItems.add(lidSuelta);
            
        }
        redraw();
    }
    
    /**
     * Manage lid- Requisito 3 
     */
    public void popLid() {
        for(int i = stackItems.size()-1; i>=0; i--){
            StackItem item = stackItems.get(i);
            if(item instanceof Lid){
                item.makeInvisible();
                stackItems.remove(i);
                break;
            }
                    
            if(item instanceof Cup){
                Cup cup = (Cup) item;
                if(cup.hasLid()){
                    cup.makeInvisible();
                    stackItems.remove(i);
                    break;
                            
                }
            }
        }
        if(visible){
            redraw();
        }
    }
    
    /**
     * Manage lid- Requisito 3
     */
    public void removeLid(int id) {
        for(int i = 0; i < stackItems.size(); i++){
            StackItem item = stackItems.get(i);
            if(item instanceof Lid){
                Lid lid = (Lid) item;
                if(lid.getId() == id){
                    lid.makeInvisible();
                    stackItems.remove(i);
                    break;
                }
            }
            
            if(item instanceof Cup){
                Cup cup = (Cup) item;
                if(cup.hasLid()){
                    if(cup.getLid().getId() == id){
                        cup.makeInvisible();
                        stackItems.remove(i);
                        break;
                    }
                }
            }
        }
        if(visible){
            redraw();
        }
    }
    
    
    /**
     * Reorganize tower- requisito 4 y 5
     */
    public void orderTower() {
        for(int i = 0; i < stackItems.size()-1; i++){
            for(int j = 0; j < stackItems.size()-1-i; j++){
                if(stackItems.get(j).getId() > stackItems.get(j+1).getId()){
                    StackItem temp = stackItems.get(j);
                    stackItems.set(j, stackItems.get(j+1));
                    stackItems.set(j+1, temp);
                }
            }
        }
        if(visible){
            redraw();
        }
    }
    
    /**
     * Reorganize tower- requisito 4 y 5
     */
    public void reverseTower() {
        Collections.reverse(stackItems);
        if(visible){
            redraw();
        }
    }
    
    /**
     * Consult information- Requisito 6 y 7
     */
    public int[] lidedCups(){
        ArrayList<Integer> lidsList = new ArrayList<>();
        for (StackItem item : stackItems) {
            if (item instanceof Cup) {
                Cup cup = (Cup) item;
                if (cup.hasLid()) {
                lidsList.add(cup.getId());
                }
            }
        }
        int[] result = new int[lidsList.size()];
        for (int i = 0; i < lidsList.size(); i++) {
            result[i] = lidsList.get(i);
        }
        
        Arrays.sort(result);
        return result;
    }
    
    /**
     * Consult information- Requisito 6 y 7
     */
    public int height() {
        int totalHeight = 0;
        int ultimateHeight = 0;
        boolean blockedCup = false;
        
        for (StackItem item : stackItems) {
            // Caso 1: El elemento es una TAZA (que puede o no tener tapa)
            if (item instanceof Cup) {
                Cup cup = (Cup) item;
                int hCup = 2 * cup.getId() - 1;
                
                // Regla de apilamiento:
                // Sumamos altura si es la primera, si la anterior tiene tapa (blocked),
                // o si esta taza es más grande que la anterior (no encaja).
                if (ultimateHeight == 0 || blockedCup || hCup > ultimateHeight) {
                    totalHeight += hCup;
                }
                
                // Si la taza tiene tapa, sumamos 1 al total (la unidad completa es más alta)
                if (cup.hasLid()) {
                    totalHeight += 1;
                    blockedCup = true; // La tapa bloquea a la siguiente taza
                } else {
                    blockedCup = false;
                }
                
                ultimateHeight = hCup;
            } 
            // Caso 2: El elemento es una TAPA SUELTA
            else if (item instanceof Lid) {
                totalHeight += 1;
                blockedCup = true; // Una tapa suelta siempre bloquea
                ultimateHeight = 0; // Al ser plana arriba, reseteamos el encaje
            }
        }
        return totalHeight;
    }
    
    /**
     * Consult information- Requisito 6 y 7
     */
    public String[][] stackingItems() {
        String [][] info = new String[stackItems.size()][2];
        
        for(int i = 0; i < stackItems.size(); i++){
            StackItem item = stackItems.get(i);
            info[i][0] = item.getType();
            info[i][1] = String.valueOf(item.getId());
        }
        return info;
    }
    
    /**
     * Set visibility- Requisito 8 
     */
    public void makeVisible() { 
        visible = true; 
        for(StackItem item: stackItems){
            item.makeVisible();
        }
        redraw(); 
    }
    
    /**
     * Set visibility- Requisito 8 
     */
    public void makeInvisible() { 
        for(StackItem item: stackItems) item.makeInvisible();
        visible = false;
    }
    
    /**
     * Exit simulator-Requisito 9
     */
    public void exit() { 
        makeInvisible();  
        stackItems.clear();
    }
    
    /**
     * Reorganize Tower-Requisito 11 y 12
     */
    public void swap(String o1, String o2) {
        StackItem item1 = null; 
        StackItem item2 = null;
        for (StackItem s : stackItems) {
            String repre = s.getType() + "," + s.getId();
            
            if(repre.equals(o1)){
                item1 = s;
            }
            
            if(repre.equals(o2)){
                item2 = s;
            }
        }
        if(item1 == null || item2 == null){
            return;
        }
        
        int pos1 = stackItems.indexOf(item1);
        int pos2 = stackItems.indexOf(item2);
        
        StackItem temp = stackItems.get(pos1);
        stackItems.set(pos1, stackItems.get(pos2));
        stackItems.set(pos2, temp);
        
        if(visible){
            redraw();
        }
    }

    /**
     * Reorganize Tower-Requisito 11 y 12
     */
    public void cover() {
        for(int i = 0; i < stackItems.size(); i++){
            StackItem item = stackItems.get(i);
    
            if(item instanceof Cup){
                Cup cup = (Cup) item;
    
                if(!cup.hasLid()){
                    Lid lid = new Lid(cup.getId(), cup.getColor());
                    cup.putLid(lid);
                }
            }
        }
    
        if(visible){
            redraw();
        }
    }

    
    /**
     * Consult Information -Requisito 13
     */
    public String[][] swapToReduce() {
        int alturaOriginal = height();
        for (int i = 0; i < stackItems.size(); i++) {
            for (int j = i + 1; j < stackItems.size(); j++){
                
                StackItem temp = stackItems.get(i);
                stackItems.set(i, stackItems.get(j));
                stackItems.set(j,temp);
                
                int newHeight = height();
                
                if(newHeight < alturaOriginal){
                    String[][] result = new String[2][1];
                    
                    result[0][0] = stackItems.get(j).getType() + "," + stackItems.get(j).getId();
                    result[1][0] = stackItems.get(i).getType() + "," + stackItems.get(i).getId();
                    
                    temp = stackItems.get(i);
                    stackItems.set(i, stackItems.get(j));
                    stackItems.set(j, temp);
                    
                    return result;
                }
                temp = stackItems.get(i);
                stackItems.set(i, stackItems.get(j));
                stackItems.set(j, temp);
            }
        }
        return new String[0][0];
    }

    // ===================== Métodos privados =====================
    private static final String[] COLORS = {
        "red", "yellow", "blue", "magenta", "black", "green"
    };
    
    private String randomColor() {
        Random rand = new Random();
        return COLORS[rand.nextInt(COLORS.length)];
    }
    
    private void redraw() {
        if (!visible) return;
    
        int centroCanvas = 400; 
        int baseInicialY = 500; 
        int[] sueloDeTaza = new int[200005]; // Aumentado para n grande
        Arrays.fill(sueloDeTaza, baseInicialY);
    
        StackItem itemAnterior = null;
    
        for (StackItem item : stackItems) {
            int w = item.getPixelWidth();
            int h = item.getPixelHeight();
            int x = centroCanvas - (w / 2);
            int yPos;
    
            if (itemAnterior == null) {
                yPos = baseInicialY - h;
            } else {
                // REGLA MEJORADA:
                // Una tapa (Lid) siempre se apoya sobre lo que sea que esté inmediatamente abajo.
                // Una taza (Cup) decide si entra o se sube.
                
                boolean debeEntrar = (item.getId() < itemAnterior.getId());
                boolean anteriorBloqueado = (itemAnterior instanceof Cup && ((Cup)itemAnterior).hasLid());
    
                if (debeEntrar && !anteriorBloqueado) {
                    // Entra al fondo de la anterior
                    yPos = (sueloDeTaza[itemAnterior.getId()] - 5) - h; 
                } else {
                    // Se apoya en los BORDES (o sobre la tapa de la anterior)
                    yPos = (sueloDeTaza[itemAnterior.getId()] - itemAnterior.getPixelHeight()) - h;
                }
            }
    
            item.draw(x, yPos);
            
            // Actualizamos el registro de posición para el siguiente item
            sueloDeTaza[item.getId()] = yPos + h;
            itemAnterior = item;
        }
    }
    
}